import { BEATS, TOTAL_FRAMES, f } from "../src/data/beats";
import { poseAt } from "../src/lib/camera";
import timings from "../src/data/timings.json";
import loud from "../src/data/loudness.json";
let bad = 0; const fail = (m: string) => { bad++; console.log("FAIL " + m); };
if (TOTAL_FRAMES !== Math.round(timings.duration * 30)) fail("frame count");
for (let i = 0; i < BEATS.length; i++) {
  const b = BEATS[i]; const next = BEATS[i + 1];
  if (next && Math.abs(b.s1 - next.s0) > 1e-6) fail(`${b.id} ends ${b.s1} but ${next.id} starts ${next.s0}`);
  let t = b.s0; for (const s of b.shots) { if (Math.abs(s.s0 - t) > 1e-6) fail(`${b.id}/${s.id} gap or overlap at ${t}`); t = s.s1; }
  if (Math.abs(t - b.s1) > 1e-6) fail(`${b.id} shots end ${t}, beat ends ${b.s1}`);
}
if (Math.abs(BEATS[0].s0) > 1e-6 || Math.abs(BEATS.at(-1)!.s1 - timings.duration) > 1e-6) fail("timeline does not span the audio");
// every sentence starts inside the beat that is meant to carry it
const sentBeat: Record<number, string> = { 1: "B1", 2: "B2", 3: "B3", 4: "B4", 5: "B5", 6: "B6", 7: "B7", 8: "B8", 9: "B9", 10: "B10", 11: "B11", 12: "B12", 13: "B13", 14: "B14" };
for (const s of timings.sentences) { const b = BEATS.find(b => s.start >= b.s0 - 1e-6 && s.start < b.s1 - 1e-6); if (!b || b.id !== sentBeat[s.id]) fail(`sentence ${s.id} starts in ${b?.id}`); }
// camera poses finite on every frame, and cut sizes
let n = 0, minShot = 99;
for (let fr = 0; fr < TOTAL_FRAMES; fr++) {
  const sec = fr / 30; const sh = BEATS.flatMap(b => b.shots).find(s => sec >= s.s0 - 1e-6 && sec < s.s1 - 1e-6);
  if (!sh) { fail(`no shot at frame ${fr}`); break; }
  const p = poseAt(sh.cam, sec - sh.s0); if ([...p.pos, ...p.look].some(v => !Number.isFinite(v))) { fail(`NaN pose at frame ${fr}`); break; }
  n++;
}
for (const s of BEATS.flatMap(b => b.shots)) minShot = Math.min(minShot, s.s1 - s.s0);
const shots = BEATS.flatMap(b => b.shots);
console.log(`${n} frames resolved, ${shots.length} shots, shortest ${minShot.toFixed(2)} s, loudness frames ${(loud as any).loudness.length} (audio needs ${TOTAL_FRAMES})`);
console.log(bad ? `${bad} failure(s)` : "timeline OK");
process.exit(bad ? 1 : 0);
