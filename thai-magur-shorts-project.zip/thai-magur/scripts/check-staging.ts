// Staging check by calculation: framing (fully in or fully out), camera distance, clearances, camera path safety.
import { BEATS } from "../src/data/beats";
import { CASTS, SOLIDS, CARD_W, CARD_H } from "../src/data/cast";
import { poseAt } from "../src/lib/camera";
import { V3 } from "../src/lib/math";

const SHOT_CAST: Record<string, string> = { "4a": "B4", "4b": "B4", "6a": "B6", "12": "B12", "13a": "B13s", "13b": "B13s", "13c": "B13p", "13d": "B13p" };
const FOV = 40 * Math.PI / 180, ASPECT = 16 / 9;
const sub = (a: V3, b: V3): V3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot = (a: V3, b: V3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a: V3, b: V3): V3 => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (a: V3): V3 => { const l = Math.hypot(...a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };

function project(pos: V3, look: V3, roll: number, p: V3) {
  const fwd = norm(sub(look, pos));
  const up0: V3 = [Math.sin(roll), Math.cos(roll), 0];
  const right = norm(cross(fwd, up0)); const up = cross(right, fwd);
  const d = sub(p, pos); const z = dot(d, fwd);
  if (z <= 0.05) return null;
  const th = Math.tan(FOV / 2);
  return [dot(d, right) / (z * th * ASPECT), dot(d, up) / (z * th)] as [number, number];
}
let fails = 0, notes = 0;
const fail = (m: string) => { fails++; console.log("FAIL  " + m); };
const note = (m: string) => { notes++; console.log("note  " + m); };

for (const beat of BEATS) for (const shot of beat.shots) {
  if (shot.world === "card") continue;
  const dur = shot.s1 - shot.s0;
  const ts = [0, 0.25, 0.5, 0.75, 1].map(u => u * (dur - 0.001));
  const key = SHOT_CAST[shot.id];
  const cast = key ? CASTS[key] : [];
  const solids = key ? SOLIDS[key] || [] : [];
  for (const t of ts) {
    const w = shot.cam.whip;
    if (w && ((w.mode === "out" && t > w.from - 0.05) || (w.mode === "in" && t < w.to + 0.05))) continue; // whip frames are blurred transitions
    const pose = poseAt(shot.cam, t);
    if (pose.pos[1] < 0.2) fail(`${shot.id} t=${t.toFixed(2)} camera below 0.2 m`);
    for (const c of cast) {
      const dxz = Math.hypot(pose.pos[0] - c.pos[0], pose.pos[2] - c.pos[2]);
      if (dxz < 3.4) fail(`${shot.id} t=${t.toFixed(2)} camera ${dxz.toFixed(2)} m from ${c.id} (< 3.4 m)`);
      const corners: V3[] = [];
      const fwd = norm(sub(pose.look, pose.pos)); // billboard faces the camera: use horizontal right vector
      const toCam = norm([pose.pos[0] - c.pos[0], 0, pose.pos[2] - c.pos[2]]);
      const r: V3 = [toCam[2], 0, -toCam[0]];
      for (const sx of [-1, 1]) for (const y of [0, CARD_H]) corners.push([c.pos[0] + sx * r[0] * CARD_W / 2, y, c.pos[2] + sx * r[2] * CARD_W / 2]);
      const pr = corners.map(q => project(pose.pos, pose.look, pose.roll, q));
      if (pr.some(q => q === null)) { fail(`${shot.id} t=${t.toFixed(2)} ${c.id} partly behind camera`); continue; }
      const P = pr as [number, number][];
      const inside = P.every(q => Math.abs(q[0]) <= 0.96 && Math.abs(q[1]) <= 0.96);
      const outside = P.every(q => q[0] < -1) || P.every(q => q[0] > 1) || P.every(q => q[1] < -1) || P.every(q => q[1] > 1);
      if (!inside && !outside) fail(`${shot.id} t=${t.toFixed(2)} ${c.id} is cut by the frame edge`);
    }
    for (const s of solids) { // camera must not sit inside a prop
      if (Math.abs(pose.pos[0] - s.x) < s.hw && Math.abs(pose.pos[2] - s.z) < s.hd && pose.pos[1] < s.h) fail(`${shot.id} camera inside ${s.name}`);
    }
  }
}
for (const [key, cast] of Object.entries(CASTS)) {
  for (let i = 0; i < cast.length; i++) {
    for (let j = i + 1; j < cast.length; j++) {
      const d = Math.hypot(cast[i].pos[0] - cast[j].pos[0], cast[i].pos[2] - cast[j].pos[2]);
      if (d < 1.2 * CARD_W) fail(`${key}: ${cast[i].id}-${cast[j].id} only ${d.toFixed(2)} m apart (< ${(1.2 * CARD_W).toFixed(2)})`);
      else note(`${key}: ${cast[i].id}-${cast[j].id} spacing ${d.toFixed(2)} m OK`);
    }
    for (const s of SOLIDS[key] || []) {
      const dx = Math.max(Math.abs(cast[i].pos[0] - s.x) - s.hw, 0), dz = Math.max(Math.abs(cast[i].pos[2] - s.z) - s.hd, 0);
      const d = Math.hypot(dx, dz);
      if (d < CARD_W && s.h > 0.3) fail(`${key}: ${cast[i].id} only ${d.toFixed(2)} m from ${s.name} (< ${CARD_W})`);
      else if (s.h > 0.3) note(`${key}: ${cast[i].id} to ${s.name} clearance ${d.toFixed(2)} m OK`);
    }
  }
}
console.log(`\n${fails} failure(s), ${notes} passing clearance notes`);
process.exit(fails ? 1 : 0);
