// Optional: needs network. Downloads Kalam Bold (handwritten, supports Devanagari + Latin) and embeds it as base64.
import fs from "fs";
const url = "https://github.com/google/fonts/raw/main/ofl/kalam/Kalam-Bold.ttf";
const res = await fetch(url);
if (!res.ok) throw new Error("download failed: " + res.status);
const b64 = Buffer.from(await res.arrayBuffer()).toString("base64");
let s = fs.readFileSync("src/lib/fontData.ts", "utf8");
s = s.replace(/export const KALAM_B64[^\n]*\n/, `export const KALAM_B64: string | null = "${b64}";\n`);
fs.writeFileSync("src/lib/fontData.ts", s);
console.log("Kalam embedded.");
