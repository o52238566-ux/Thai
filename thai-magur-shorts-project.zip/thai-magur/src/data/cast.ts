// Pure data (no three/react) so the staging check can run in plain node.
import { V3 } from "../lib/math";
export type Role = "farmer" | "officer" | "trader";
export type Expr = "smile" | "happy" | "concerned" | "deadpan" | "surprised";
export type Pose = "idle" | "cheer" | "hips" | "point" | "hold";
export interface Cast { id: string; role: Role; pos: V3; face: number; acts: Array<[number, Expr, Pose]> } // acts: [seconds from beat start, expr, pose]
// footprint boxes used for wall/prop clearance: centre x,z, half width, half depth, height
export interface Solid { name: string; x: number; z: number; hw: number; hd: number; h: number }

export const CARD_W = 0.975;   // width of a cut-out card (used as "body width" for clearance)
export const CARD_H = 1.95;
export const FEET_PX = 752;    // y of the feet in the 400x800 character canvas

export const CASTS: Record<string, Cast[]> = {
  B4: [{ id: "farmer", role: "farmer", pos: [3.2, 0, 3.4], face: Math.PI, acts: [[0, "concerned", "hips"]] }],
  B6: [{ id: "farmer", role: "farmer", pos: [1.2, 0, 3.3], face: -0.35, acts: [[0, "happy", "cheer"]] }],
  B12: [{ id: "trader", role: "trader", pos: [1.4, 0, -2.9], face: 0, acts: [[0, "deadpan", "idle"]] }],
  B13s: [ // station part of B13 (to 4.63 s)
    { id: "officer", role: "officer", pos: [-4.4, 0, 1.0], face: Math.PI / 2, acts: [[0, "deadpan", "idle"]] },
    { id: "trader", role: "trader", pos: [4.4, 0, 1.0], face: -Math.PI / 2, acts: [[0, "concerned", "idle"]] }],
  B13p: [ // Assam pond part of B13 (from 4.63 s)
    { id: "officer", role: "officer", pos: [-1.0, 0, 3.0], face: Math.PI, acts: [[0, "deadpan", "idle"]] },
    { id: "farmer", role: "farmer", pos: [6.5, 0, 2.2], face: -2.4, acts: [[0, "concerned", "idle"]] }],
};
export const SOLIDS: Record<string, Solid[]> = {
  B4: [{ name: "pond rim", x: 0, z: -1.5, hw: 7, hd: 3, h: 0.0 }, { name: "height board", x: -2, z: 3, hw: 0.2, hd: 0.1, h: 2.2 }],
  B6: [{ name: "coin machine", x: -2.5, z: 3.0, hw: 0.8, hd: 0.6, h: 1.8 }],
  B12: [{ name: "stall table", x: 0, z: -1.2, hw: 1.6, hd: 0.6, h: 0.9 }],
  B13s: [{ name: "container 1", x: -2.0, z: -1.8, hw: 0.9, hd: 0.7, h: 1.2 }, { name: "container 2", x: 0, z: -1.8, hw: 0.9, hd: 0.7, h: 1.2 }, { name: "container 3", x: 2.0, z: -1.8, hw: 0.9, hd: 0.7, h: 1.2 }],
  B13p: [{ name: "crate heap", x: 2.2, z: 0.4, hw: 1.0, hd: 0.7, h: 1.0 }, { name: "pit", x: 4.2, z: 0.6, hw: 0.8, hd: 0.6, h: 0.0 }, { name: "counter post", x: 2.6, z: -1.0, hw: 0.15, hd: 0.15, h: 2.4 }],
};
