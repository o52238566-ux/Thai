import timings from "./timings.json";
import { V3, FPS } from "../lib/math";
import { CamSpec } from "../lib/camera";

export type WorldId = "pond" | "market" | "studio" | "waters" | "under" | "station" | "card";
export interface Shot { id: string; s0: number; s1: number; angle: string; world: WorldId; cam: CamSpec }
export interface Beat { id: string; s0: number; s1: number; shots: Shot[] }

export const TOTAL_FRAMES = Math.round(timings.duration * FPS); // 2546
const V = (x: number, y: number, z: number): V3 => [x, y, z];
// orbit keys around a centre (used for the closing shot)
const orbit = (c: V3, r: number, h: number, degs: number[]) => degs.map(a => V(c[0] + r * Math.sin(a * Math.PI / 180), h, c[2] + r * Math.cos(a * Math.PI / 180)));
const C14: V3 = [0, 0.3, -1.0];

export const BEATS: Beat[] = [
  { id: "B1", s0: 0, s1: 9.63, shots: [
    { id: "1a", s0: 0, s1: 3.5, angle: "Establishing high-wide", world: "pond", cam: { p: [V(-7, 13, 18), V(-3, 9, 13)], l: [V(0, 0, -3)], dur: 3.5 } },
    { id: "1b", s0: 3.5, s1: 6.0, angle: "Object hero shot", world: "pond", cam: { p: [V(2.2, 1.5, 5.2), V(0.9, 0.9, 3.4)], l: [V(0, 0.1, -2.1)], dur: 1.0 } },
    { id: "1c", s0: 6.0, s1: 9.63, angle: "Ground-level", world: "pond", cam: { p: [V(-2.6, 0.8, 5.4), V(-1.4, 0.7, 4.4)], l: [V(0.2, -0.4, -2.2), V(0.2, -0.55, -2.2)], dur: 3.0 } } ] },
  { id: "B2", s0: 9.63, s1: 15.23, shots: [
    { id: "2a", s0: 9.63, s1: 11.8, angle: "Through-the-frame", world: "market", cam: { p: [V(0.3, 1.3, 7.2), V(0.05, 1.1, 5.4)], l: [V(-0.35, 0.85, -1.2)], dur: 1.6 } },
    { id: "2b", s0: 11.8, s1: 15.23, angle: "Title card over object hero", world: "market", cam: { p: [V(0, 1.05, 5.0), V(-0.1, 1.0, 4.3)], l: [V(-0.4, 0.95, -1.2)], dur: 3.4 } } ] },
  { id: "B3", s0: 15.23, s1: 20.8, shots: [
    { id: "3a", s0: 15.23, s1: 17.6, angle: "Object hero shot", world: "studio", cam: { p: [V(1.4, 1.3, 4.0), V(0.9, 1.2, 3.2)], l: [V(0, 1.15, 0)], dur: 0.9 } },
    { id: "3b", s0: 17.6, s1: 20.8, angle: "Table-top, straight down", world: "studio", cam: { p: [V(0, 6.4, 2.4), V(0, 5.6, 0.7)], l: [V(0, 0, 0)], dur: 1.2 } } ] },
  { id: "B4", s0: 20.8, s1: 26.6, shots: [
    { id: "4a", s0: 20.8, s1: 23.3, angle: "Back view reveal", world: "pond", cam: { p: [V(3.9, 1.5, 7.4), V(3.6, 1.4, 7.0)], l: [V(0.4, 0.7, -1.5)], dur: 2.4 } },
    { id: "4b", s0: 23.3, s1: 26.6, angle: "Object hero shot", world: "pond", cam: { p: [V(-1.6, 1.3, 6.3), V(-1.3, 1.25, 5.6)], l: [V(-1.3, 1.05, 3.0)], dur: 0.8 } } ] },
  { id: "B5", s0: 26.6, s1: 31.07, shots: [
    { id: "5a", s0: 26.6, s1: 28.4, angle: "Object hero shot (punch-in)", world: "studio", cam: { p: [V(-1.2, 1.9, 2.4)], l: [V(-1.2, 1.9, -1.5)], dur: 0 } },
    { id: "5b", s0: 28.4, s1: 31.07, angle: "Object hero shot", world: "studio", cam: { p: [V(1.8, 1.3, 2.8)], l: [V(1.8, 0.9, -0.5)], dur: 0 } } ] },
  { id: "B6", s0: 31.07, s1: 34.63, shots: [
    { id: "6a", s0: 31.07, s1: 32.9, angle: "Hero low angle", world: "pond", cam: { p: [V(0.2, 0.6, 8.6), V(0.1, 0.7, 8.0)], l: [V(-0.6, 1.3, 3.2)], dur: 1.8 } },
    { id: "6b", s0: 32.9, s1: 34.63, angle: "Black card", world: "card", cam: { p: [V(0, 1, 5)], l: [V(0, 1, 0)], dur: 0 } } ] },
  { id: "B7", s0: 34.63, s1: 38.87, shots: [
    { id: "7a", s0: 34.63, s1: 36.8, angle: "Object hero shot", world: "pond", cam: { p: [V(1.6, 0.9, 4.7), V(1.2, 0.8, 4.2)], l: [V(0.1, 0.05, 0.2)], dur: 2.0 } },
    { id: "7b", s0: 36.8, s1: 38.87, angle: "Ground-level, dolly into mouth", world: "pond", cam: { p: [V(-1.4, 0.4, 3.7), V(0.7, 0.22, 1.1)], l: [V(0.5, 0.1, 0.2), V(1.05, 0.05, 0.2)], delay: 0.6, dur: 1.3 } } ] },
  { id: "B8", s0: 38.87, s1: 47.87, shots: [
    { id: "8a", s0: 38.87, s1: 42.3, angle: "Through-the-frame", world: "pond", cam: { p: [V(-3.3, 0.9, 3.4), V(-2.7, 0.9, 3.0)], l: [V(1.0, 0.05, -1.4)], dur: 3.2 } },
    { id: "8b", s0: 42.3, s1: 45.0, angle: "Object hero shot", world: "pond", cam: { p: [V(2.2, 0.9, 3.4), V(1.6, 0.85, 3.0)], l: [V(0.5, 0.05, -0.2)], dur: 0.8 } },
    { id: "8c", s0: 45.0, s1: 47.87, angle: "Ground-level", world: "pond", cam: { p: [V(-9.0, 0.5, -1.4), V(-8.0, 0.5, -1.3)], l: [V(4.0, 0.1, -1.2)], dur: 2.7 } } ] },
  { id: "B9", s0: 47.87, s1: 54.4, shots: [
    { id: "9a", s0: 47.87, s1: 50.0, angle: "Establishing high-wide, slight tilt", world: "waters", cam: { p: [V(-17, 9, 12), V(-16, 8, 11)], l: [V(-11, 0, -0.5)], dur: 2.1, roll: 0.09 } },
    { id: "9b", s0: 50.0, s1: 54.4, angle: "Follow", world: "waters", cam: { p: [V(-13, 3, 6.5), V(-3, 3.2, 7.5), V(8, 4.6, 9.5), V(20, 5.8, 10.5), V(27, 1.6, 7)], l: [V(-9, 0.3, 0), V(2, 0.2, 0), V(12, 0.3, 0), V(24, 0.3, 0), V(28, 0, 0)], dur: 4.4 } } ] },
  { id: "B10", s0: 54.4, s1: 60.67, shots: [
    { id: "10a", s0: 54.4, s1: 56.9, angle: "Object hero shot, low", world: "under", cam: { p: [V(1.0, 0.5, 6.6), V(0.6, 0.7, 6.0)], l: [V(-0.8, 2.4, 0)], dur: 2.2 } },
    { id: "10b", s0: 56.9, s1: 60.67, angle: "Through-the-frame", world: "under", cam: { p: [V(4.6, 1.5, 6.4), V(4.0, 1.5, 5.8)], l: [V(2.2, 1.3, 0)], dur: 3.6 } } ] },
  { id: "B11", s0: 60.67, s1: 62.17, shots: [
    { id: "11", s0: 60.67, s1: 62.17, angle: "Black card", world: "card", cam: { p: [V(0, 1, 5)], l: [V(0, 1, 0)], dur: 0 } } ] },
  { id: "B12", s0: 62.17, s1: 65.37, shots: [
    { id: "12", s0: 62.17, s1: 65.37, angle: "Through-the-frame", world: "market", cam: { p: [V(0, 1.55, 6.2), V(0.05, 1.42, 4.7)], l: [V(0.4, 1.05, -1.4)], dur: 3.0 } } ] },
  { id: "B13", s0: 65.37, s1: 75.33, shots: [
    { id: "13a", s0: 65.37, s1: 67.2, angle: "Establishing high-wide", world: "station", cam: { p: [V(-8.5, 7, 15), V(-6, 6.2, 13.5)], l: [V(0, 1, -1.5)], dur: 1.8 } },
    { id: "13b", s0: 67.2, s1: 70.0, angle: "Two-shot profile, then whip-pan", world: "station", cam: { p: [V(0, 1.5, 10.2)], l: [V(0, 1.3, 0)], dur: 0, whip: { from: 2.35, to: 2.8, dx: 16, mode: "out" } } },
    { id: "13c", s0: 70.0, s1: 71.5, angle: "Establishing high-wide (whip-in)", world: "pond", cam: { p: [V(-6, 8, 14), V(-4.5, 7, 12.5)], l: [V(0, 0, -1)], dur: 1.5, whip: { from: 0, to: 0.35, dx: 16, mode: "in" } } },
    { id: "13d", s0: 71.5, s1: 75.33, angle: "Back view reveal", world: "pond", cam: { p: [V(-0.6, 1.5, 7.4), V(-0.3, 1.45, 7.0)], l: [V(1.4, 0.9, 0.5)], dur: 3.8 } } ] },
  { id: "B14", s0: 75.33, s1: timings.duration, shots: [
    { id: "14a", s0: 75.33, s1: 78.5, angle: "Object hero shot", world: "pond", cam: { p: [V(0.6, 1.25, 6.4), V(0.3, 1.15, 5.9)], l: [V(0, 0.95, 3.2)], dur: 3.1 } },
    { id: "14b", s0: 78.5, s1: 80.6, angle: "Ground-level", world: "pond", cam: { p: [V(-1.8, 0.35, 2.9), V(-1.2, 0.32, 2.6)], l: [V(0.6, -0.05, -2.2)], dur: 2.0 } },
    { id: "14c", s0: 80.6, s1: timings.duration, angle: "Slow partial orbit", world: "pond", cam: { p: orbit(C14, 6.2, 1.1, [-24, -9, 5, 16]), l: [C14], dur: 4.25 } } ] },
];

export const f = (sec: number) => Math.round(sec * FPS);
export { C14 };
