import React, { useMemo } from "react";
import * as THREE from "three";
import { V3, rng, smooth, clamp } from "../lib/math";
import { Ink, Flat, Lights, Sky, Sign, Net, Clouds } from "../rig/kit";
import { PAL } from "../lib/draw";

export type Tod = "dawn" | "day" | "dusk";
const TOD = {
  dawn: { bg: "#F1CFA8", sky: "#FFE7C8", gr: "#8D9A74", sun: "#FFB070", sunI: 0.9, ground: "#9CA97E" },
  day: { bg: "#CFE6EA", sky: "#FFFFFF", gr: "#9DB58C", sun: "#FFF4D8", sunI: 1.2, ground: "#8FB27A" },
  dusk: { bg: "#E39A6B", sky: "#FFD2A6", gr: "#6F7A6A", sun: "#FF9A55", sunI: 0.8, ground: "#7C8E6A" },
};
const RX = 7, RZ = 4.5, PZ = -3;

// ---------- POND: ground with a real hole, mud basin, translucent water, reeds, hut, trees ----------
export function PondWorld({ t, tod, waterY = 0, murky = false, foreReeds = false, clouds = true }: { t: number; tod: Tod; waterY?: number; murky?: boolean; foreReeds?: boolean; clouds?: boolean }) {
  const T = TOD[tod];
  const groundGeo = useMemo(() => {
    const s = new THREE.Shape(); s.moveTo(-60, -60); s.lineTo(60, -60); s.lineTo(60, 60); s.lineTo(-60, 60); s.closePath();
    const h = new THREE.Path(); h.absellipse(0, -PZ, RX, RZ, 0, Math.PI * 2, true); s.holes.push(h);
    return new THREE.ShapeGeometry(s, 48);
  }, []);
  const reeds = useMemo(() => { const r = rng(7); return Array.from({ length: 30 }, (_, i) => { const a = Math.PI * (1.05 + r() * 0.9); return { x: Math.cos(a) * (RX + 0.3 + r() * 0.8), z: PZ + Math.sin(a) * (RZ + 0.3 + r() * 0.6), h: 1.0 + r() * 0.9, ph: r() * 6 }; }); }, []);
  const trees = useMemo(() => [[-14, -9], [13, -10], [-18, 2], [17, -3], [-6, -18], [8, -20]] as [number, number][], []);
  const water = murky ? "#6F7040" : "#5FA3A6";
  return (<>
    <Sky color={T.bg} fogNear={45} fogFar={130} />
    <Lights sky={T.sky} ground={T.gr} sun={T.sun} sunI={T.sunI} />
    <mesh geometry={groundGeo} rotation={[-Math.PI / 2, 0, 0]}><meshToonMaterial color={T.ground} side={THREE.DoubleSide} /></mesh>
    {/* path and grass patches so the ground is not one flat colour */}
    <Flat w={3} d={30} color="#C9B58B" p={[5, 0.005, 14]} />
    {[[-9, 6], [9, 7], [-4, 11], [12, 2]].map(([x, z], i) => <Flat key={i} w={2.2} d={0} round color="#7FA06A" p={[x, 0.006, z]} sx={1.2} sz={0.6} />)}
    <mesh position={[0, -0.45, PZ]} scale={[RX, 1, RZ]}><cylinderGeometry args={[1, 1, 0.9, 48, 1, true]} /><meshToonMaterial color="#6B4A2C" side={THREE.DoubleSide} /></mesh>
    <Flat w={1} d={0} round color="#5A3D24" p={[0, -0.9, PZ]} sx={RX} sz={RZ} />
    <Flat w={1} d={0} round color={water} p={[0, waterY, PZ]} sx={RX} sz={RZ} opacity={waterY < -0.7 ? 0 : 0.86} />
    {/* rim stones */}
    {Array.from({ length: 16 }, (_, i) => { const a = i / 16 * Math.PI * 2; return <Ink key={i} g="sphere" a={[0.22]} color="#9A8E78" p={[Math.cos(a) * (RX + 0.25), 0.1, PZ + Math.sin(a) * (RZ + 0.25)]} s={[1.3, 0.7, 1]} line={0.02} />; })}
    {reeds.map((r, i) => <Ink key={i} g="cone" a={[0.07, r.h, 6]} color="#5E8A55" p={[r.x, r.h / 2, r.z]} r={[0, 0, Math.sin(t * 0.8 + r.ph) * 0.05]} line={0.015} />)}
    {foreReeds && [[-2.3, 2.6], [-1.9, 2.5], [-1.5, 2.7], [-1.1, 2.55]].map(([x, z], i) => <group key={i}>{[0, 0.12, -0.1].map((d, k) => <Ink key={k} g="cone" a={[0.06, 1.6 + k * 0.2, 6]} color="#4F7D49" p={[x + d, 0.85 + k * 0.1, z]} r={[0, 0, Math.sin(t + i + k) * 0.05]} line={0.02} />)}</group>)}
    {/* hut */}
    <group position={[-10, 0, -6]}><Ink g="box" a={[3, 1.8, 2.4]} color="#C9B58B" p={[0, 0.9, 0]} /><Ink g="cone" a={[2.6, 1.4, 4]} color={PAL.wood} p={[0, 2.5, 0]} r={[0, Math.PI / 4, 0]} /><Ink g="box" a={[0.7, 1.2, 0.1]} color={PAL.wood} p={[0, 0.6, 1.25]} /></group>
    {/* drying rack */}
    <group position={[9, 0, -2]}><Ink g="cyl" a={[0.05, 0.05, 1.6, 8]} color={PAL.wood} p={[-1, 0.8, 0]} /><Ink g="cyl" a={[0.05, 0.05, 1.6, 8]} color={PAL.wood} p={[1, 0.8, 0]} /><Ink g="cyl" a={[0.04, 0.04, 2.2, 8]} color={PAL.wood} p={[0, 1.6, 0]} r={[0, 0, Math.PI / 2]} /></group>
    {trees.map(([x, z], i) => <group key={i} position={[x, 0, z]}><Ink g="cyl" a={[0.25, 0.32, 3, 10]} color={PAL.wood} p={[0, 1.5, 0]} /><Ink g="sphere" a={[1.8]} color="#5E8A55" p={[0, 3.8, 0]} s={[1, 0.85, 1]} /><Ink g="sphere" a={[1.2]} color="#6E9A62" p={[1.1, 3.2, 0.3]} /></group>)}
    {clouds && <Clouds t={t} />}
  </>);
}

// ---------- WATERS: pond -> bund gap -> channel -> lake -> river ----------
export function WatersWorld({ t }: { t: number }) {
  const trees = useMemo(() => { const r = rng(11); return Array.from({ length: 26 }, () => [-20 + r() * 70, (r() < 0.5 ? -1 : 1) * (7 + r() * 14)] as [number, number]); }, []);
  const W = "#5FA3A6";
  return (<>
    <Sky color="#CFE6EA" fogNear={40} fogFar={110} />
    <Lights sky="#FFFFFF" ground="#9DB58C" sun="#FFF4D8" sunI={1.2} />
    <Flat w={200} d={120} color="#8FB27A" p={[10, 0, 0]} />
    <Flat w={1} d={0} round color="#7A6A44" p={[-14, 0.015, 0]} sx={5.4} sz={3.9} /><Flat w={1} d={0} round color={W} p={[-14, 0.02, 0]} sx={5} sz={3.5} />
    <Flat w={9} d={1.6} color={W} p={[-4.6, 0.02, 0]} />
    <Flat w={1} d={0} round color={W} p={[7, 0.02, 0]} sx={6} sz={4.5} />
    <Flat w={34} d={7.6} color="#7A6A44" p={[30, 0.012, 0]} /><Flat w={34} d={7} color={W} p={[30, 0.02, 0]} />
    <Ink g="box" a={[0.8, 0.7, 3.2]} color="#7A5A38" p={[-9.2, 0.35, -2.4]} /><Ink g="box" a={[0.8, 0.7, 3.2]} color="#7A5A38" p={[-9.2, 0.35, 2.4]} />
    {Array.from({ length: 12 }, (_, i) => <Flat key={i} w={1.4} d={0.08} color="#FFFFFF" p={[-8 + i * 1.3 + ((t * 2) % 1.3), 0.03, (i % 3 - 1) * 0.35]} opacity={0.6} />)}
    {trees.map(([x, z], i) => <group key={i} position={[x, 0, z]}><Ink g="cyl" a={[0.22, 0.28, 2.6, 10]} color={PAL.wood} p={[0, 1.3, 0]} /><Ink g="sphere" a={[1.5]} color={i % 2 ? "#5E8A55" : "#6E9A62"} p={[0, 3.3, 0]} s={[1, 0.85, 1]} /></group>)}
    <Clouds t={t} y={16} z={-30} count={6} />
  </>);
}

// ---------- UNDER: below the river surface ----------
export function UnderWorld({ t }: { t: number }) {
  const r = rng(21);
  const weeds = useMemo(() => Array.from({ length: 26 }, () => ({ x: -6 + r() * 16, z: -4 + r() * 3, h: 1.2 + r() * 2.2, ph: r() * 6 })), []);
  const fore = [3.2, 3.9, 4.5, 5.1, 5.6].map((x, i) => ({ x, z: 3.2 + (i % 2) * 0.3, h: 3.0 + (i % 3) * 0.4, ph: i }));
  return (<>
    <Sky color="#4F8FA0" fogNear={14} fogFar={46} />
    <Lights sky="#BFE9F0" ground="#3C6F7B" sun="#E8FFFF" sunI={0.9} dir={[0, 12, 4]} />
    <Flat w={90} d={50} color="#C9B27E" p={[0, 0, -4]} />
    {[[-7, 1], [8, -2], [-2, -6]].map(([x, z], i) => <Ink key={i} g="sphere" a={[0.9]} color="#8E8A78" p={[x, 0.3, z]} s={[1.4, 0.7, 1]} />)}
    {[...weeds, ...fore].map((w, i) => <Ink key={i} g="cone" a={[0.09, w.h, 6]} color={i % 2 ? "#4C7A4E" : "#5E8A55"} p={[w.x, w.h / 2, w.z]} r={[0, 0, Math.sin(t * 0.9 + w.ph) * 0.09]} line={0.02} />)}
    {[-4, 2, 7].map((x, i) => <mesh key={i} position={[x, 5, -3]} rotation={[0, 0, 0.18]}><coneGeometry args={[2.4, 10, 16, 1, true]} /><meshBasicMaterial color="#FFFFFF" transparent opacity={0.07} depthWrite={false} side={THREE.DoubleSide} /></mesh>)}
  </>);
}

// ---------- MARKET ----------
export function MarketWorld({ t, mode }: { t: number; mode: "cross" | "nets" }) {
  return (<>
    <Sky color="#EBD9B8" fogNear={30} fogFar={80} />
    <Lights sky="#FFF6E0" ground="#B8A07A" sun="#FFE8B0" sunI={1.0} />
    <Flat w={60} d={40} color="#C9B58B" p={[0, 0, -6]} />
    {Array.from({ length: 8 }, (_, i) => <Flat key={i} w={1.4} d={0.1} color="#B8A27A" p={[-8 + i * 2.3, 0.006, 3 + (i % 2)]} />)}
    {/* back wall with painted panels, windows and posters so a pan never crosses a blank wall */}
    <Ink g="box" a={[34, 6, 0.4]} color="#D8C9A6" p={[0, 3, -9]} />
    {Array.from({ length: 9 }, (_, i) => <Ink key={i} g="box" a={[1.6, 1.5, 0.1]} color={i % 2 ? PAL.slate : PAL.teal} p={[-14 + i * 3.5, 3.4, -8.75]} line={0.03} />)}
    {Array.from({ length: 6 }, (_, i) => <Ink key={i} g="box" a={[0.8, 1.1, 0.06]} color={PAL.paper} p={[-11 + i * 4.4, 1.7, -8.76]} line={0.025} />)}
    {/* the stall */}
    <Ink g="box" a={[3.2, 0.9, 1.2]} color={PAL.wood} p={[0, 0.45, -1.2]} />
    <Ink g="box" a={[3.4, 0.08, 1.4]} color="#8A6038" p={[0, 0.92, -1.2]} line={0.025} />
    {[-1.7, 1.7].map(x => <Ink key={x} g="cyl" a={[0.06, 0.06, 2.8, 8]} color={PAL.wood} p={[x, 1.4, -1.8]} line={0.02} />)}
    {Array.from({ length: 8 }, (_, i) => <Ink key={i} g="box" a={[0.45, 0.06, 1.7]} color={i % 2 ? PAL.teal : PAL.paper} p={[-1.57 + i * 0.45, 2.85 - 0.0, -1.55]} r={[0.22, 0, 0]} line={0.02} />)}
    <Ink g="cyl" a={[0.55, 0.45, 0.35, 24]} color={PAL.slate} p={[-0.4, 1.12, -1.2]} />
    <Ink g="cyl" a={[0.34, 0.3, 0.3, 20]} color="#7C8F94" p={[1.0, 1.1, -1.1]} /><Ink g="cyl" a={[0.34, 0.3, 0.3, 20]} color="#7C8F94" p={[1.0 + 0.7, 1.1, -1.25]} />
    {/* neighbours' stalls */}
    {[-5.5, 5.5].map(x => <group key={x}><Ink g="box" a={[2.6, 0.9, 1.1]} color="#7A5A38" p={[x, 0.45, -2.0]} /><Ink g="box" a={[0.7, 0.45, 0.5]} color="#B8A27A" p={[x - 0.7, 1.1, -2.0]} /><Ink g="box" a={[0.7, 0.45, 0.5]} color="#B8A27A" p={[x + 0.7, 1.1, -2.0]} /></group>)}
    <group position={[2.9, 0, -0.8]}><Ink g="cyl" a={[0.05, 0.05, 2.0, 8]} color={PAL.wood} p={[0, 1.0, 0]} line={0.02} /><Sign pos={[0, 1.8, 0.08]} size={[1.5, 0.55]} lines={["ताज़ा मछली"]} /></group>
    {mode === "cross" ? (<>
      <Ink g="cyl" a={[0.045, 0.045, 4.4, 8]} color="#B9A25A" p={[0, 1.6, 3.8]} r={[0, 0, 0.5]} line={0.02} />
      <Ink g="cyl" a={[0.045, 0.045, 4.4, 8]} color="#B9A25A" p={[0, 1.6, 3.8]} r={[0, 0, -0.5]} line={0.02} />
      <Sign pos={[0.02, 1.35 - Math.sin(t * 1.5) * 0.02, 3.85]} size={[0.9, 0.32]} lines={["BANNED"]} bg="#F4F1EA" fs={62} />
    </>) : (<>
      {[-2.6, 2.6].map(x => <Ink key={x} g="cyl" a={[0.06, 0.06, 3.4, 8]} color="#B9A25A" p={[x, 1.7, 3.4]} line={0.02} />)}
      <Net pos={[-2.0, 2.35, 3.4]} size={[1.4, 1.9]} /><Net pos={[2.0, 2.35, 3.4]} size={[1.4, 1.9]} />
    </>)}
  </>);
}

// ---------- STUDIO: a plain set for objects (wall + wood floor) ----------
export function StudioWorld({ t }: { t: number }) {
  return (<>
    <Sky color="#E8DFC9" fogNear={25} fogFar={60} />
    <Lights sky="#FFF6E0" ground="#B8A07A" sun="#FFF4D8" sunI={1.1} dir={[3, 8, 6]} />
    <Ink g="box" a={[16, 0.2, 10]} color="#A57C52" p={[0, -0.1, 0]} line={0.04} />
    {Array.from({ length: 9 }, (_, i) => <Flat key={i} w={16} d={0.05} color="#8A6540" p={[0, 0.003, -4.4 + i * 1.1]} />)}
    <Ink g="box" a={[16, 7, 0.3]} color="#E8DFC9" p={[0, 3.5, -4.3]} />
    {Array.from({ length: 7 }, (_, i) => <Ink key={i} g="box" a={[0.9, 0.9, 0.05]} color={i % 2 ? "#D5C7A6" : "#CFC0A0"} p={[-6 + i * 2, 5.4, -4.1]} line={0.02} />)}
    <Ink g="box" a={[16, 0.12, 0.2]} color={PAL.wood} p={[0, 1.0, -4.1]} line={0.02} />
  </>);
}

// ---------- STATION: Jabalpur platform with roof, signboard, lamps ----------
export function StationWorld({ t }: { t: number }) {
  return (<>
    <Sky color="#D6E3E3" fogNear={40} fogFar={110} />
    <Lights sky="#FFFFFF" ground="#8F8B80" sun="#FFF4D8" sunI={1.0} />
    <Flat w={60} d={22} color="#9B9A94" p={[0, 0, 1]} />
    {Array.from({ length: 12 }, (_, i) => <Flat key={i} w={0.1} d={22} color="#8C8B85" p={[-12 + i * 2.2, 0.004, 1]} />)}
    <Flat w={60} d={0.25} color="#E3B93C" p={[0, 0.006, -5.2]} />
    <Flat w={60} d={4} color="#4A3A2A" p={[0, -0.04, -7.4]} /><Flat w={60} d={0.12} color="#8A8A8A" p={[0, 0.02, -6.7]} /><Flat w={60} d={0.12} color="#8A8A8A" p={[0, 0.02, -8.1]} />
    <Ink g="box" a={[40, 5.5, 0.4]} color="#C9B58B" p={[0, 2.75, -12]} />
    {Array.from({ length: 10 }, (_, i) => <Ink key={i} g="box" a={[1.4, 1.6, 0.1]} color={PAL.slate} p={[-14 + i * 3.1, 3, -11.75]} line={0.03} />)}
    <Ink g="box" a={[28, 0.3, 14]} color="#6E7B80" p={[0, 4.7, -2]} />
    {[-9, -3, 3, 9].map(x => <Ink key={x} g="cyl" a={[0.16, 0.16, 4.6, 10]} color="#7C8F94" p={[x, 2.3, -4.2]} line={0.03} />)}
    <mesh position={[1, 2.4, -2]} rotation={[0, 0, -0.08]}><coneGeometry args={[1.6, 4.4, 16, 1, true]} /><meshBasicMaterial color="#FFF3C9" transparent opacity={0.1} depthWrite={false} side={THREE.DoubleSide} /></mesh>
    <group position={[-6.4, 0, -4.2]}><Ink g="cyl" a={[0.05, 0.05, 2.0, 8]} color={PAL.wood} p={[-0.7, 1.0, 0]} /><Ink g="cyl" a={[0.05, 0.05, 2.0, 8]} color={PAL.wood} p={[0.7, 1.0, 0]} /><Sign pos={[0, 1.75, 0.06]} size={[2.0, 0.7]} lines={["जबलपुर"]} bg={PAL.slate} fg="#FFFFFF" /></group>
    {[-12, 12].map(x => <group key={x} position={[x, 0, -3.5]}><Ink g="cyl" a={[0.05, 0.05, 3, 8]} color="#555" p={[0, 1.5, 0]} /><Ink g="sphere" a={[0.2]} color="#FFE7A8" p={[0, 3.1, 0]} /></group>)}
    <Ink g="box" a={[3.4, 0.12, 0.8]} color={PAL.wood} p={[7.6, 0.5, -3.7]} line={0.025} />
  </>);
}
