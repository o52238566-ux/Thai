import { useEffect, useState } from "react";
import { continueRender, delayRender } from "remotion";
import { DEV_FONT_B64, KALAM_B64 } from "./fontData";

// Loads embedded fonts (base64) into document.fonts before the first frame draws.
export function useFonts(): boolean {
  const [ready, setReady] = useState(false);
  const [handle] = useState(() => delayRender("fonts"));
  useEffect(() => {
    const load = async () => {
      const faces: Array<[string, string]> = [["Dev", DEV_FONT_B64]];
      if (KALAM_B64) faces.unshift(["Kalam", KALAM_B64]);
      for (const [name, b64] of faces) {
        const ff = new FontFace(name, `url(data:font/ttf;base64,${b64})`, { weight: "700" });
        await ff.load(); (document as any).fonts.add(ff);
      }
      setReady(true); continueRender(handle);
    };
    load().catch(() => { setReady(true); continueRender(handle); });
  }, [handle]);
  return ready;
}
export const FONT = "Kalam, Dev, sans-serif";
