import { V3, catmull, clamp, easeInCubic } from "./math";

export interface CamSpec {
  p: V3[];            // camera positions (waypoints the camera passes through at speed)
  l: V3[];            // look-at targets, same count as p (or 1)
  delay?: number;     // seconds after the cut before the move starts
  dur: number;        // seconds the move takes; afterwards the camera holds with a slight drift
  roll?: number;      // radians of frame tilt (slight tilt)
  whip?: { from: number; to: number; dx: number; mode: "out" | "in" }; // whip-pan, seconds in shot
  noDrift?: boolean;
}
export interface Pose { pos: V3; look: V3; roll: number; whipBlur: number }

// One continuous curve. Only the very start and very end of the move slow down:
// the parameter uses a gentle ease (sine in/out) so speed never drops to zero mid-path.
const ease = (u: number) => 0.5 - 0.5 * Math.cos(Math.PI * clamp(u));

export function poseAt(spec: CamSpec, tt: number): Pose {
  const delay = spec.delay ?? 0;
  const u = spec.dur <= 0 ? 1 : clamp((tt - delay) / spec.dur);
  const s = spec.p.length === 1 ? 0 : (spec.dur <= 0 ? 1 : ease(u));
  const pos = catmull(spec.p, s);
  const look = catmull(spec.l.length === 1 ? [spec.l[0]] : spec.l, s);
  if (!spec.noDrift) { // very slow hand-held drift keeps held shots alive
    pos[0] += Math.sin(tt * 0.9) * 0.035; pos[1] += Math.sin(tt * 1.3 + 1) * 0.02; pos[2] += Math.sin(tt * 0.7 + 2) * 0.035;
    look[0] += Math.sin(tt * 0.6 + 4) * 0.03;
  }
  let whipBlur = 0;
  if (spec.whip) {
    const w = spec.whip; const p = clamp((tt - w.from) / (w.to - w.from));
    if (w.mode === "out") { look[0] += w.dx * easeInCubic(p); whipBlur = p > 0 ? easeInCubic(p) : 0; }
    else { look[0] += -w.dx * Math.pow(1 - p, 3); whipBlur = p < 1 ? Math.pow(1 - p, 3) : 0; }
  }
  return { pos, look, roll: spec.roll ?? 0, whipBlur };
}
