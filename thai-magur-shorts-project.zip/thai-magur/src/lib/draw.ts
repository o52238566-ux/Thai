// All art is drawn in code onto 2D canvases (no image files). Flat toon fills, #111111 ink line.
import type { Role, Expr, Pose } from "../data/cast";
export type View = "front" | "three" | "side" | "back";
export const PAL = { teal: "#4A6B6E", wood: "#6E4726", slate: "#2C3E50", paper: "#F4F1EA", khaki: "#B8A47A", accent: "#FF8800", ink: "#111111", rust: "#8A4A2B" };
export const CW = 400, CH = 800;
const INK = PAL.ink;
const SKIN: Record<Role, string> = { farmer: "#B07850", officer: "#D9A47A", trader: "#C98E5E" };

type Ctx = CanvasRenderingContext2D;
const rr = (c: Ctx, x: number, y: number, w: number, h: number, r: number[]) => { c.beginPath(); (c as any).roundRect(x, y, w, h, r); };
const line = (c: Ctx, pts: number[][], w = 8, col = INK) => { c.strokeStyle = col; c.lineWidth = w; c.lineCap = "round"; c.lineJoin = "round"; c.beginPath(); c.moveTo(pts[0][0], pts[0][1]); for (const p of pts.slice(1)) c.lineTo(p[0], p[1]); c.stroke(); };

export function drawCharacter(c: Ctx, role: Role, view: View, expr: Expr, pose: Pose, blink: boolean) {
  c.clearRect(0, 0, CW, CH);
  const cx = 200, headY = 138, R = 82;
  const tw = view === "side" ? 100 : view === "three" ? 150 : 170;
  const tx = cx - tw / 2 + (view === "three" ? 6 : 0), ty = 218, th = 296;
  const skin = SKIN[role];
  const body: Record<Role, string> = { farmer: PAL.teal, officer: PAL.khaki, trader: PAL.paper };
  const hem: Record<Role, string> = { farmer: "#355356", officer: "#8F7E5A", trader: "#B0B0B0" };
  // legs + shoes
  const lx = view === "side" ? [190, 212] : [cx - 32, cx + 32];
  for (const x of lx) { line(c, [[x, ty + th - 6], [x, 735]], 10); }
  for (const x of lx) { c.fillStyle = INK; c.beginPath(); c.ellipse(x + (view === "side" ? 8 : 0), 744, 23, 10, 0, 0, 7); c.fill(); c.fillStyle = "rgba(255,255,255,.35)"; c.beginPath(); c.ellipse(x - 6 + (view === "side" ? 8 : 0), 740, 7, 3, 0, 0, 7); c.fill(); }
  // torso
  c.save(); rr(c, tx, ty, tw, th, [tw * 0.46, tw * 0.46, 30, 30]); c.fillStyle = body[role]; c.fill(); c.clip();
  if (role === "farmer") { // check shirt
    c.strokeStyle = "#3C595C"; c.lineWidth = 3;
    for (let x = tx + 10; x < tx + tw; x += 18) { c.beginPath(); c.moveTo(x, ty); c.lineTo(x, ty + th); c.stroke(); }
    for (let y = ty + 14; y < ty + th; y += 18) { c.beginPath(); c.moveTo(tx, y); c.lineTo(tx + tw, y); c.stroke(); }
  }
  if (role === "trader" && view !== "back") { // brown waistcoat with a V opening, teal sash
    c.fillStyle = PAL.wood; rr(c, tx, ty + 18, tw * 0.36, th, [10, 10, 10, 10]); c.fill(); rr(c, tx + tw * 0.64, ty + 18, tw * 0.36, th, [10, 10, 10, 10]); c.fill();
    c.setLineDash([8, 8]); c.strokeStyle = "rgba(255,255,255,.7)"; c.lineWidth = 3; c.beginPath(); c.moveTo(tx + tw * 0.2, ty + 60); c.lineTo(tx + tw * 0.2, ty + th - 40); c.stroke(); c.setLineDash([]);
    if (view !== "side") { line(c, [[tx + 6, ty + 34], [tx + tw - 4, ty + th - 80]], 20, PAL.teal); }
  }
  if (role === "trader" && view === "back") { c.fillStyle = PAL.wood; rr(c, tx + 6, ty + 18, tw - 12, th, [14, 14, 10, 10]); c.fill(); }
  if (role === "officer" && view !== "back") { // placket, badge, lanyard
    line(c, [[cx, ty + 20], [cx, ty + th - 40]], 3, "#8F7E5A");
    for (let y = ty + 70; y < ty + th - 60; y += 46) { c.fillStyle = "#8F7E5A"; c.beginPath(); c.arc(cx, y, 4, 0, 7); c.fill(); }
    if (view !== "side") { c.fillStyle = "#E3B93C"; c.beginPath(); c.arc(tx + tw * 0.22, ty + 92, 9, 0, 7); c.fill(); c.strokeStyle = INK; c.lineWidth = 3; c.stroke();
      line(c, [[cx - 8, ty + 14], [cx - 4, ty + 150]], 4, "#FFFFFF"); c.fillStyle = "#FFFFFF"; c.fillRect(cx - 18, ty + 150, 28, 34); c.strokeStyle = INK; c.lineWidth = 3; c.strokeRect(cx - 18, ty + 150, 28, 34); }
  }
  if (role === "farmer" && view === "front") { c.strokeStyle = INK; c.lineWidth = 3; c.strokeRect(tx + 18, ty + 96, 26, 30); }
  // hem band, shade, rim light
  c.fillStyle = hem[role]; c.fillRect(tx, ty + th - 34, tw, 34);
  c.fillStyle = "rgba(0,0,0,.14)"; c.beginPath(); c.ellipse(tx + tw * 1.0, ty + th * 0.45, tw * 0.42, th * 0.75, 0, 0, 7); c.fill();
  c.fillStyle = "rgba(255,255,255,.12)"; c.fillRect(tx + 6, ty + 20, 8, th - 80);
  c.restore(); rr(c, tx, ty, tw, th, [tw * 0.46, tw * 0.46, 30, 30]); c.strokeStyle = INK; c.lineWidth = 7; c.stroke();
  if (role === "officer" && view !== "side") { c.fillStyle = INK; c.fillRect(tx - 6, ty + 14, 16, 10); c.fillRect(tx + tw - 10, ty + 14, 16, 10); }
  // head
  c.save(); c.beginPath(); c.arc(cx, headY, R, 0, 7); c.fillStyle = skin; c.fill(); c.clip();
  const g = c.createRadialGradient(cx - 10, headY - 10, R * 0.4, cx, headY, R); g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, "rgba(0,0,0,.18)"); c.fillStyle = g; c.fillRect(cx - R, headY - R, 2 * R, 2 * R);
  c.fillStyle = "rgba(0,0,0,.12)"; c.beginPath(); c.ellipse(cx + R * 0.95, headY + 6, R * 0.5, R * 1.1, 0, 0, 7); c.fill();
  // hat
  const hatCol = role === "farmer" ? PAL.rust : role === "officer" ? PAL.slate : "#FFFFFF";
  c.fillStyle = hatCol; c.fillRect(cx - R, headY - R - 4, 2 * R, R - 14 + 4);
  c.fillStyle = role === "trader" ? "#BDBDBD" : "#111111"; c.fillRect(cx - R, headY - 22, 2 * R, role === "trader" ? 14 : 12);
  c.fillStyle = "rgba(255,255,255,.28)"; c.beginPath(); c.ellipse(cx - 30, headY - 56, 28, 6, -0.4, 0, 7); c.fill();
  c.restore(); c.beginPath(); c.arc(cx, headY, R, 0, 7); c.strokeStyle = INK; c.lineWidth = 7; c.stroke();
  if (role === "officer" && view !== "back") { // cap peak
    c.fillStyle = PAL.slate; c.strokeStyle = INK; c.lineWidth = 5; c.beginPath();
    if (view === "side") { c.moveTo(cx + 40, headY - 14); c.lineTo(cx + R + 40, headY - 6); c.lineTo(cx + 40, headY + 2); } else { const o = view === "three" ? 14 : 0; c.moveTo(cx - 60 + o, headY - 14); c.lineTo(cx + 60 + o, headY - 14); c.lineTo(cx + 50 + o, headY + 4); c.lineTo(cx - 50 + o, headY + 4); }
    c.closePath(); c.fill(); c.stroke();
  }
  // face
  if (view !== "back") drawFace(c, view, expr, blink, cx, headY);
  // arms
  drawArms(c, role, view, pose, tx, tw, ty, skin);
}

function drawFace(c: Ctx, view: View, expr: Expr, blink: boolean, cx: number, hy: number) {
  const shift = view === "three" ? 22 : view === "side" ? 46 : 0;
  const sp = view === "three" ? 24 : 32;
  const eyes: number[] = view === "side" ? [cx + shift] : [cx - sp + shift, cx + sp + shift];
  const ey = hy + 14;
  c.fillStyle = INK; c.strokeStyle = INK; c.lineCap = "round";
  for (const x of eyes) {
    if (blink) { c.lineWidth = 5; c.beginPath(); c.moveTo(x - 8, ey); c.lineTo(x + 8, ey); c.stroke(); }
    else { c.beginPath(); c.ellipse(x, ey, expr === "surprised" ? 10 : 7, expr === "surprised" ? 13 : 10, 0, 0, 7); c.fill(); }
    // brows
    c.lineWidth = 4; c.beginPath();
    const by = ey - 28; const inner = x < cx + shift ? 1 : -1;
    if (expr === "concerned") { c.moveTo(x - 10 * inner, by + 7 * (view === "side" ? 0 : 1) + 0); c.lineTo(x + 10 * inner, by - 6); }
    else if (expr === "deadpan") { c.moveTo(x - 10, by + 4); c.lineTo(x + 10, by + 4); }
    else if (expr === "surprised") { c.moveTo(x - 10, by - 6); c.quadraticCurveTo(x, by - 14, x + 10, by - 6); }
    else { c.moveTo(x - 10, by + 2); c.quadraticCurveTo(x, by - 4, x + 10, by + 2); }
    c.stroke();
  }
  const mx = cx + shift + (view === "side" ? 4 : 0), my = hy + 50;
  c.lineWidth = 5; c.beginPath();
  if (expr === "happy") { c.moveTo(mx - 22, my - 6); c.quadraticCurveTo(mx, my + 30, mx + 22, my - 6); c.closePath(); c.fillStyle = INK; c.fill(); c.fillStyle = "#F6F2EA"; c.fillRect(mx - 14, my - 4, 28, 6); }
  else if (expr === "concerned") { c.moveTo(mx - 14, my + 8); c.quadraticCurveTo(mx, my - 6, mx + 14, my + 8); c.stroke(); }
  else if (expr === "deadpan") { c.moveTo(mx - 14, my + 2); c.lineTo(mx + 14, my + 2); c.stroke(); }
  else if (expr === "surprised") { c.ellipse(mx, my + 4, 8, 11, 0, 0, 7); c.fill(); }
  else { c.moveTo(mx - 18, my - 2); c.quadraticCurveTo(mx, my + 18, mx + 18, my - 2); c.stroke(); }
}

function drawArms(c: Ctx, role: Role, view: View, pose: Pose, tx: number, tw: number, ty: number, skin: string) {
  const sleeve = role === "farmer" ? PAL.teal : role === "officer" ? PAL.khaki : PAL.paper;
  const arm = (pts: number[][]) => { line(c, pts, 17, INK); line(c, pts, 10, sleeve); const h = pts[pts.length - 1]; c.fillStyle = skin; c.strokeStyle = INK; c.lineWidth = 5; c.beginPath(); c.arc(h[0], h[1], 12, 0, 7); c.fill(); c.stroke(); };
  const L = tx + 8, Rr = tx + tw - 8, sy = ty + 44;
  if (pose === "idle" || view === "side" || view === "back") {
    if (view !== "back") for (const x of [L + 10, Rr - 10]) { c.strokeStyle = "rgba(0,0,0,.35)"; c.lineWidth = 3; c.beginPath(); c.moveTo(x, ty + 70); c.lineTo(x, ty + 230); c.stroke(); }
    if (pose === "idle") return;
  }
  if (pose === "cheer") { arm([[L, sy], [L - 40, sy - 40], [L - 52, sy - 110]]); arm([[Rr, sy], [Rr + 40, sy - 40], [Rr + 52, sy - 110]]); }
  if (pose === "hips") { arm([[L, sy + 10], [L - 36, sy + 70], [L + 4, sy + 120]]); arm([[Rr, sy + 10], [Rr + 36, sy + 70], [Rr - 4, sy + 120]]); }
  if (pose === "point") { arm([[Rr, sy], [Rr + 70, sy + 20], [Rr + 118, sy + 24]]); }
  if (pose === "hold") { arm([[Rr, sy + 6], [Rr + 40, sy + 70], [Rr + 4, sy + 120]]); }
}

// ---- hero fish (faces right), 800x320 ----
export const FW = 800, FH = 320;
export function drawHeroFish(c: Ctx, mouthOpen = 0) {
  c.clearRect(0, 0, FW, FH); c.lineJoin = "round"; c.lineCap = "round";
  const olive = "#5B6B5E", belly = "#A9B8A0", fin = "#4A5A4E";
  const ink = (w = 7) => { c.strokeStyle = INK; c.lineWidth = w; c.stroke(); };
  c.fillStyle = fin; c.beginPath(); c.moveTo(190, 112); c.lineTo(250, 66); c.lineTo(520, 60); c.lineTo(520, 120); c.closePath(); c.fill(); ink(); // long dorsal fin
  c.fillStyle = olive; c.beginPath(); c.moveTo(100, 176); c.lineTo(30, 112); c.lineTo(40, 176); c.lineTo(30, 240); c.closePath(); c.fill(); ink(); // tail
  c.fillStyle = olive; c.beginPath(); c.ellipse(360, 176, 270, 82, 0, 0, 7); c.fill(); ink(8);
  c.save(); c.beginPath(); c.ellipse(360, 176, 270, 82, 0, 0, 7); c.clip(); c.fillStyle = belly; c.beginPath(); c.ellipse(330, 214, 210, 42, 0, 0, 7); c.fill(); c.restore();
  c.fillStyle = fin; c.beginPath(); c.moveTo(420, 240); c.lineTo(500, 292); c.lineTo(470, 292); c.lineTo(390, 244); c.closePath(); c.fill(); ink(6); // pectoral
  const h = mouthOpen * 26; // flat head
  c.fillStyle = "#55655A"; rr(c, 520, 104, 210, 130 + h * 0, [30, 50, 30, 30]); c.fill(); ink(8);
  if (h > 0) { c.fillStyle = "#2a1410"; c.beginPath(); c.moveTo(728, 190); c.lineTo(790, 190 - h * 0.5); c.lineTo(790, 190 + h); c.lineTo(728, 220); c.closePath(); c.fill(); ink(5); }
  c.fillStyle = INK; c.beginPath(); c.arc(690, 146, 9, 0, 7); c.fill(); c.fillStyle = "#fff"; c.beginPath(); c.arc(693, 143, 3, 0, 7); c.fill();
  for (const [dx, dy] of [[64, -38], [72, -14], [66, 18], [48, 44]]) { line(c, [[724, 196], [724 + dx, 196 + dy]], 5, "#E8E0C8"); } // four whiskers
  c.fillStyle = "rgba(255,255,255,.18)"; c.beginPath(); c.ellipse(330, 130, 160, 10, -0.03, 0, 7); c.fill();
}
// ---- small native fish (faces right), 400x200 ----
export function drawNativeFish(c: Ctx, dead = false) {
  c.clearRect(0, 0, 400, 200); c.lineJoin = "round";
  const ink = (w = 6) => { c.strokeStyle = INK; c.lineWidth = w; c.stroke(); };
  c.fillStyle = "#9FB0B4"; c.beginPath(); c.moveTo(80, 100); c.lineTo(20, 52); c.lineTo(30, 100); c.lineTo(20, 148); c.closePath(); c.fill(); ink();
  c.fillStyle = "#C5D0D2"; c.beginPath(); c.ellipse(220, 100, 150, 58, 0, 0, 7); c.fill(); ink(7);
  c.strokeStyle = PAL.slate; c.lineWidth = 6; c.beginPath(); c.moveTo(110, 104); c.lineTo(330, 104); c.stroke();
  c.fillStyle = "#9FB0B4"; c.beginPath(); c.moveTo(200, 46); c.lineTo(240, 14); c.lineTo(270, 50); c.closePath(); c.fill(); ink(5);
  if (dead) { line(c, [[318, 80], [342, 100]], 5); line(c, [[342, 80], [318, 100]], 5); }
  else { c.fillStyle = INK; c.beginPath(); c.arc(330, 90, 8, 0, 7); c.fill(); c.fillStyle = "#fff"; c.beginPath(); c.arc(333, 87, 3, 0, 7); c.fill(); }
}
// ---- hand-lettered sign / counter board ----
export function drawSign(c: Ctx, w: number, h: number, lines: string[], bg: string, fg: string, border = INK, size = 0, font = "Kalam, Dev, sans-serif") {
  c.clearRect(0, 0, w, h); rr(c, 4, 4, w - 8, h - 8, [18, 18, 18, 18]); c.fillStyle = bg; c.fill(); c.strokeStyle = border; c.lineWidth = 8; c.stroke();
  const fs = size || Math.min(h / (lines.length + 0.6), w / Math.max(4, Math.max(...lines.map(l => l.length)) * 0.62));
  c.fillStyle = fg; c.textAlign = "center"; c.textBaseline = "middle"; c.font = `bold ${fs}px ${font}`;
  lines.forEach((t, i) => c.fillText(t, w / 2, h / 2 + (i - (lines.length - 1) / 2) * fs * 1.15));
}
export function drawGlow(c: Ctx, size: number, color = "255,136,0") {
  c.clearRect(0, 0, size, size); const g = c.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, `rgba(${color},0.9)`); g.addColorStop(0.35, `rgba(${color},0.4)`); g.addColorStop(1, `rgba(${color},0)`); c.fillStyle = g; c.fillRect(0, 0, size, size);
}
export function drawNet(c: Ctx, w: number, h: number) {
  c.clearRect(0, 0, w, h); c.strokeStyle = "rgba(17,17,17,.75)"; c.lineWidth = 3;
  for (let x = 0; x <= w; x += 36) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, h); c.stroke(); }
  for (let y = 0; y <= h; y += 36) { c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke(); }
}
