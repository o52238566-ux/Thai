export type V3 = [number, number, number];
export const FPS = 30;
export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smooth = (t: number) => { t = clamp(t); return t * t * (3 - 2 * t); };
export const easeInCubic = (t: number) => { t = clamp(t); return t * t * t; };
export const easeOutCubic = (t: number) => { t = clamp(t); return 1 - Math.pow(1 - t, 3); };
export const easeOutBack = (t: number) => { t = clamp(t); const c = 1.70158; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); };
// pop 0.8 -> 1.05 -> 1.0 over `dur` seconds
export const pop = (t: number, dur = 0.25) => {
  if (t <= 0) return 0.0001;
  const u = clamp(t / dur);
  if (u < 0.6) return lerp(0.8, 1.05, smooth(u / 0.6));
  return lerp(1.05, 1.0, smooth((u - 0.6) / 0.4));
};
export const wrapPi = (a: number) => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };
// deterministic pseudo random (mulberry32)
export const rng = (seed: number) => () => {
  seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
// Uniform Catmull-Rom through points, s in [0,1] over the whole path
export function catmull(pts: V3[], s: number): V3 {
  if (pts.length === 1) return pts[0];
  const n = pts.length - 1;
  const x = clamp(s) * n;
  const i = Math.min(n - 1, Math.floor(x));
  const u = x - i;
  const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(n, i + 2)];
  const out: V3 = [0, 0, 0];
  for (let k = 0; k < 3; k++) {
    out[k] = 0.5 * ((2 * p1[k]) + (-p0[k] + p2[k]) * u + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * u * u + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * u * u * u);
  }
  return out;
}
export const dist = (a: V3, b: V3) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
