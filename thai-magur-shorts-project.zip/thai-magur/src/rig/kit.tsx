import React, { createContext, useContext, useLayoutEffect, useMemo } from "react";
import * as THREE from "three";
import { useThree } from "@react-three/fiber";
import { V3, wrapPi, rng, clamp, smooth } from "../lib/math";
import { Pose } from "../lib/camera";
import { Cast, CARD_W, CARD_H, FEET_PX } from "../data/cast";
import { drawCharacter, drawHeroFish, drawNativeFish, drawSign, drawGlow, drawNet, CW, CH, FW, FH, PAL, View } from "../lib/draw";
import { FONT } from "../lib/fonts";

export const CamCtx = createContext<{ pos: V3 }>({ pos: [0, 2, 10] });

export function CameraRig({ pose }: { pose: Pose }) {
  const { camera } = useThree();
  useLayoutEffect(() => {
    camera.up.set(Math.sin(pose.roll), Math.cos(pose.roll), 0);
    camera.position.set(pose.pos[0], pose.pos[1], pose.pos[2]);
    camera.lookAt(pose.look[0], pose.look[1], pose.look[2]);
    camera.updateMatrixWorld();
  });
  return null;
}

// ---------- textures (drawn in code, cached) ----------
const texCache = new Map<string, THREE.CanvasTexture>();
export function useTex(key: string, w: number, h: number, draw: (c: CanvasRenderingContext2D) => void) {
  return useMemo(() => {
    let t = texCache.get(key);
    if (!t) {
      const cv = document.createElement("canvas"); cv.width = w; cv.height = h; draw(cv.getContext("2d")!);
      t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; texCache.set(key, t);
    }
    return t;
  }, [key]);
}
let _grad: THREE.DataTexture | null = null;
const toonGrad = () => { if (!_grad) { _grad = new THREE.DataTexture(new Uint8Array([90, 170, 255]), 3, 1, THREE.RedFormat); _grad.minFilter = _grad.magFilter = THREE.NearestFilter; _grad.needsUpdate = true; } return _grad; };

// ---------- toon + ink outline ----------
type G = "box" | "cyl" | "sphere" | "cone";
interface InkProps { g: G; a: number[]; color: string; p?: V3; r?: V3; s?: V3; line?: number; opacity?: number; noLine?: boolean }
export function Ink({ g, a, color, p = [0, 0, 0], r = [0, 0, 0], s = [1, 1, 1], line = 0.035, opacity = 1, noLine }: InkProps) {
  const geo = (args: number[]) => g === "box" ? <boxGeometry args={args as any} /> : g === "cyl" ? <cylinderGeometry args={args as any} /> : g === "sphere" ? <sphereGeometry args={[args[0], 20, 14]} /> : <coneGeometry args={args as any} />;
  const grow = g === "box" ? [a[0] + 2 * line, a[1] + 2 * line, a[2] + 2 * line] : g === "cyl" ? [a[0] + line, a[1] + line, a[2] + 2 * line, a[3] ?? 24] : g === "sphere" ? [a[0] + line] : [a[0] + line, a[1] + 2 * line, a[2] ?? 16];
  const base = g === "cyl" ? [a[0], a[1], a[2], a[3] ?? 24] : g === "cone" ? [a[0], a[1], a[2] ?? 16] : a;
  return (
    <group position={p} rotation={r} scale={s}>
      <mesh>{geo(base)}<meshToonMaterial color={color} gradientMap={toonGrad()} transparent={opacity < 1} opacity={opacity} /></mesh>
      {!noLine && <mesh>{geo(grow)}<meshBasicMaterial color={PAL.ink} side={THREE.BackSide} transparent={opacity < 1} opacity={opacity} /></mesh>}
    </group>
  );
}
export function Flat({ w, d, color, p, opacity = 1, round = false, sx = 1, sz = 1 }: { w: number; d: number; color: string; p: V3; opacity?: number; round?: boolean; sx?: number; sz?: number }) {
  return <mesh position={p} rotation={[-Math.PI / 2, 0, 0]} scale={[sx, sz, 1]}>{round ? <circleGeometry args={[w, 48]} /> : <planeGeometry args={[w, d]} />}<meshToonMaterial color={color} gradientMap={toonGrad()} transparent={opacity < 1} opacity={opacity} side={THREE.DoubleSide} /></mesh>;
}
export function Lights({ sky, ground, sun, sunI = 1.1, hemiI = 0.9, dir = [6, 10, 6] }: { sky: string; ground: string; sun: string; sunI?: number; hemiI?: number; dir?: V3 }) {
  return (<>
    <hemisphereLight args={[sky, ground, hemiI]} />
    <ambientLight intensity={0.45} />
    <directionalLight position={dir} color={sun} intensity={sunI} />
  </>);
}
export function Sky({ color, fogNear = 40, fogFar = 120 }: { color: string; fogNear?: number; fogFar?: number }) {
  return (<><color attach="background" args={[color]} /><fog attach="fog" args={[color, fogNear, fogFar]} /></>);
}

// ---------- sprites that always face the camera ----------
function useFacing(pos: V3) { const c = useContext(CamCtx).pos; return Math.atan2(c[0] - pos[0], c[2] - pos[2]); }

export function CharacterView({ cast, t, frame }: { cast: Cast; t: number; frame: number }) {
  const yc = useFacing(cast.pos);
  const act = [...cast.acts].reverse().find(a => t >= a[0]) || cast.acts[0];
  const diff = wrapPi(cast.face - yc), ad = Math.abs(diff);
  const view: View = ad < 0.436 ? "front" : ad < 1.22 ? "three" : ad < 2.0 ? "side" : "back";
  const mirror = Math.sin(cast.face - yc) < 0;
  const f2 = frame - (frame % 2);                       // limbs and face update on twos
  const off = cast.role === "farmer" ? 40 : cast.role === "officer" ? 70 : 20; // never blink on frame 0
  const blink = f2 > 4 && ((f2 + off) % 96) < 4;
  const key = `${cast.role}|${view}|${act[1]}|${act[2]}|${blink}`;
  const tex = useTex(key, CW, CH, c => drawCharacter(c, cast.role, view, act[1], act[2], blink));
  const cy = ((FEET_PX - 400) / 800) * CARD_H;
  const bob = 1 + 0.012 * Math.sin(f2 * 0.21 + cast.pos[0]);
  return (<>
    <mesh position={[cast.pos[0], 0.012, cast.pos[2]]} rotation={[-Math.PI / 2, 0, 0]} scale={[1, 0.45, 1]}><circleGeometry args={[0.5, 24]} /><meshBasicMaterial color="#000" transparent opacity={0.22} /></mesh>
    <group position={[cast.pos[0], 0, cast.pos[2]]} rotation={[0, yc, 0]}>
      <mesh position={[0, cy * bob, 0]} scale={[mirror ? -1 : 1, bob, 1]}>
        <planeGeometry args={[CARD_W, CARD_H]} /><meshBasicMaterial map={tex} transparent alphaTest={0.04} toneMapped={false} side={THREE.DoubleSide} />
      </mesh>
    </group>
  </>);
}

export function Glow({ pos, size, loud = 0, opacity = 0.55 }: { pos: V3; size: number; loud?: number; opacity?: number }) {
  const yc = useFacing(pos);
  const tex = useTex("glow", 256, 256, c => drawGlow(c, 256));
  return <group position={pos} rotation={[0, yc, 0]}><mesh position={[0, 0, -0.03]} scale={1 + 0.12 * loud}><planeGeometry args={[size, size]} /><meshBasicMaterial map={tex} transparent opacity={opacity + 0.3 * loud} blending={THREE.AdditiveBlending} depthWrite={false} toneMapped={false} /></mesh></group>;
}

interface FishProps { kind: "hero" | "native"; pos: V3; len: number; dir?: 1 | -1; flipY?: boolean; dead?: boolean; mouth?: number; wiggle?: number; glow?: boolean; loud?: number; opacity?: number; frame?: number; rollZ?: number }
export function FishView({ kind, pos, len, dir = 1, flipY = false, dead = false, mouth = 0, wiggle = 0.04, glow = false, loud = 0, opacity = 1, frame = 0, rollZ = 0 }: FishProps) {
  const yc = useFacing(pos);
  const m = Math.round(mouth * 4) / 4;
  const tex = useTex(kind === "hero" ? `hero|${m}` : `nat|${dead}`, kind === "hero" ? FW : 400, kind === "hero" ? FH : 200, c => kind === "hero" ? drawHeroFish(c, m) : drawNativeFish(c, dead));
  const h = len * (kind === "hero" ? FH / FW : 0.5);
  const f2 = frame - (frame % 2);
  return (<>
    {glow && <Glow pos={pos} size={len * 1.9} loud={loud} />}
    <group position={pos} rotation={[0, yc, 0]}>
      <mesh rotation={[0, 0, wiggle * Math.sin(f2 * 0.18) + rollZ]} scale={[dir, flipY ? -1 : 1, 1]}>
        <planeGeometry args={[len, h]} /><meshBasicMaterial map={tex} transparent opacity={opacity} alphaTest={0.04} toneMapped={false} side={THREE.DoubleSide} />
      </mesh>
    </group>
  </>);
}

// in-world hand-lettered board. billboard=true faces the camera; otherwise lies at the given rotation.
export function Sign({ pos, size, lines, bg = PAL.paper, fg = PAL.ink, border = PAL.ink, billboard = true, rot = [0, 0, 0], scale = 1, fs = 0 }: { pos: V3; size: [number, number]; lines: string[]; bg?: string; fg?: string; border?: string; billboard?: boolean; rot?: V3; scale?: number; fs?: number }) {
  const yc = useFacing(pos);
  const W = 512, H = Math.round(512 * size[1] / size[0]);
  const tex = useTex(`sign|${lines.join("/")}|${bg}|${fg}|${W}x${H}|${fs}`, W, H, c => drawSign(c, W, H, lines, bg, fg, border, fs, FONT));
  return <group position={pos} rotation={billboard ? [0, yc, 0] : rot} scale={scale}><mesh rotation={billboard ? [0, 0, 0] : [0, 0, 0]}><planeGeometry args={size} /><meshBasicMaterial map={tex} transparent toneMapped={false} side={THREE.DoubleSide} /></mesh></group>;
}
export function Net({ pos, size, rot = [0, 0, 0] as V3 }: { pos: V3; size: [number, number]; rot?: V3 }) {
  const tex = useTex("net", 360, 360, c => drawNet(c, 360, 360));
  return <mesh position={pos} rotation={rot}><planeGeometry args={size} /><meshBasicMaterial map={tex} transparent toneMapped={false} side={THREE.DoubleSide} /></mesh>;
}

// ---------- effects (in-world, deterministic, low counts) ----------
export function Mist({ y, span = 22, count = 5, seed = 1, t, color = "#FFFFFF", opacity = 0.2, z0 = -3, zr = 6, fade = 1 }: { y: number; span?: number; count?: number; seed?: number; t: number; color?: string; opacity?: number; z0?: number; zr?: number; fade?: number }) {
  const r = rng(seed);
  return <>{Array.from({ length: count }, (_, i) => {
    const w = 5 + r() * 5, d = 0.8 + r() * 0.8, sp = 0.15 + r() * 0.2, ph = r() * span, z = z0 + (r() - 0.5) * zr, yy = y + r() * 0.12;
    const x = ((ph + t * sp) % span) - span / 2;
    return <mesh key={i} position={[x, yy, z]} rotation={[-Math.PI / 2, 0, 0]} scale={[w, d, 1]}><circleGeometry args={[0.5, 24]} /><meshBasicMaterial color={color} transparent opacity={opacity * fade} depthWrite={false} /></mesh>;
  })}</>;
}
export function Bubbles({ c, spread = [4, 3] as [number, number], count = 14, t, seed = 3, y0 = 0 }: { c: V3; spread?: [number, number]; count?: number; t: number; seed?: number; y0?: number }) {
  const r = rng(seed);
  return <>{Array.from({ length: count }, (_, i) => {
    const x = c[0] + (r() - 0.5) * spread[0], z = c[2] + (r() - 0.5) * spread[1], ph = r(), sp = 0.25 + r() * 0.25, rad = 0.04 + r() * 0.05;
    const u = (ph + t * sp) % 1; const sc = u < 0.8 ? 1 : 1 + (u - 0.8) * 3; const op = u < 0.8 ? 0.85 : 0.85 * (1 - (u - 0.8) / 0.2);
    return <mesh key={i} position={[x, y0 + u * 0.5 - 0.05, z]} scale={sc}><sphereGeometry args={[rad, 10, 8]} /><meshBasicMaterial color="#E9F2E4" transparent opacity={op} depthWrite={false} /></mesh>;
  })}</>;
}
export function Dust({ c, size = [3, 4, 3] as V3, count = 22, t, seed = 5 }: { c: V3; size?: V3; count?: number; t: number; seed?: number }) {
  const r = rng(seed);
  return <>{Array.from({ length: count }, (_, i) => {
    const x = c[0] + (r() - 0.5) * size[0] + Math.sin(t * 0.5 + i) * 0.15, y = c[1] + ((r() + t * 0.04 * (0.5 + r())) % 1) * size[1], z = c[2] + (r() - 0.5) * size[2];
    return <mesh key={i} position={[x, y, z]}><sphereGeometry args={[0.035, 8, 6]} /><meshBasicMaterial color="#FFF3C9" transparent opacity={0.7} depthWrite={false} /></mesh>;
  })}</>;
}
export function Clouds({ t, y = 14, z = -30, count = 5, seed = 9 }: { t: number; y?: number; z?: number; count?: number; seed?: number }) {
  const r = rng(seed);
  return <>{Array.from({ length: count }, (_, i) => {
    const x = (((r() * 80) + t * (0.5 + r() * 0.4)) % 80) - 40; const s = 2.5 + r() * 2;
    return <group key={i} position={[x, y + r() * 4, z - r() * 10]}>{[-1, 0, 1].map(k => <mesh key={k} position={[k * s * 0.8, k === 0 ? 0.3 * s : 0, 0]} scale={[1.2, 0.7, 0.4]}><sphereGeometry args={[s * (k === 0 ? 1.0 : 0.75), 14, 10]} /><meshBasicMaterial color="#FFFFFF" transparent opacity={0.92} /></mesh>)}</group>;
  })}</>;
}
export const hp = (v: number) => v; // placeholder to keep tree-shaking quiet
export { clamp, smooth };
