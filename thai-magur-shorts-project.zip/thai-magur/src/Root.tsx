import React from "react";
import { Composition } from "remotion";
import { Video } from "./Video";
import { TOTAL_FRAMES } from "./data/beats";

export const Root: React.FC = () => (
  <>
    <Composition id="ThaiMagur" component={Video} width={1920} height={1080} fps={30} durationInFrames={TOTAL_FRAMES} />
    <Composition id="ThaiMagurShorts" component={Video} defaultProps={{ portrait: true }} width={1080} height={1920} fps={30} durationInFrames={TOTAL_FRAMES} />
  </>
);
