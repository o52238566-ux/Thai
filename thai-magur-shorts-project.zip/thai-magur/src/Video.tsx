import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import timings from "./data/timings.json";
import loudness from "./data/loudness.json";
import { BEATS, Beat, TOTAL_FRAMES, f } from "./data/beats";
import { poseAt } from "./lib/camera";
import { FPS } from "./lib/math";
import { useFonts } from "./lib/fonts";
import { CamCtx, CameraRig } from "./rig/kit";
import { BeatWorld } from "./scenes/Beats";
import { BlackCard, TitleCard, StampTag, Wash } from "./ui/Overlays";

const LOUD: number[] = (loudness as any).loudness;
const W = 1920, H = 1080;

const BeatView: React.FC<{ beat: Beat; f0: number; portrait?: boolean }> = ({ beat, f0, portrait = false }) => {
  const lf = useCurrentFrame(); const gf = f0 + lf; const sec = gf / FPS;
  const shot = beat.shots.find(s => sec >= s.s0 - 1e-6 && sec < s.s1 - 1e-6) ?? beat.shots[beat.shots.length - 1];
  if (shot.world === "card") return <AbsoluteFill style={{ background: "#000000" }} />;
  const pose = poseAt(shot.cam, sec - shot.s0);
  const loud = LOUD[Math.min(gf, LOUD.length - 1)] ?? 0;
  const blur = pose.whipBlur > 0.02 ? `url(#hblur${gf})` : undefined;
  const canvasW = portrait ? 1080 : W;
  const canvasH = portrait ? 1920 : H;
  return (
    <AbsoluteFill style={{ filter: blur }}>
      {blur && <svg width="0" height="0" style={{ position: "absolute" }}><filter id={`hblur${gf}`}><feGaussianBlur stdDeviation={`${(70 * pose.whipBlur).toFixed(1)} 0`} /></filter></svg>}
      <ThreeCanvas width={canvasW} height={canvasH} style={{ width: canvasW, height: canvasH }} camera={{ fov: portrait ? 88 : 40, near: 0.1, far: 300, position: pose.pos }}>
        <CamCtx.Provider value={{ pos: pose.pos }}>
          <CameraRig pose={pose} />
          <BeatWorld beat={beat} shot={shot} t={sec - beat.s0} frame={gf} loud={loud} />
        </CamCtx.Provider>
      </ThreeCanvas>
    </AbsoluteFill>
  );
};

export const Video: React.FC<{ portrait?: boolean }> = ({ portrait = false }) => {
  const ready = useFonts();
  const frame = useCurrentFrame(); const sec = frame / FPS;
  const loud = LOUD[Math.min(frame, LOUD.length - 1)] ?? 0;
  if (!ready) return null;
  return (
    <AbsoluteFill style={{ background: "#F4F1EA" }}>
      <Audio src={staticFile("voice.mp3")} />
      {BEATS.map((b, i) => {
        const from = f(b.s0), to = i + 1 < BEATS.length ? f(BEATS[i + 1].s0) : TOTAL_FRAMES;
        return <Sequence key={b.id} from={from} durationInFrames={to - from}><BeatView beat={b} f0={from} portrait={portrait} /></Sequence>;
      })}
      <BlackCard sec={sec} s0={32.9} s1={34.63} text="मनी मेकिंग मशीन" loud={loud} portrait={portrait} />
      <BlackCard sec={sec} s0={60.67} s1={62.17} text="इसीलिए इस पर रोक है।" loud={loud} portrait={portrait} />
      <TitleCard sec={sec} s0={11.8} s1={15.23} loud={loud} portrait={portrait} />
      <StampTag sec={sec} s0={65.37} s1={70.0} text="SEP 2025 · JABALPUR" portrait={portrait} />
      <StampTag sec={sec} s0={70.0} s1={75.33} text="JUN 2026 · ASSAM" portrait={portrait} />
      <Wash frame={frame} at={38.87} color="#5B6B5E" />
      <Wash frame={frame} at={54.4} color="#4F8FA0" />
    </AbsoluteFill>
  );
};
