import React from "react";
import { AbsoluteFill } from "remotion";
import { clamp, easeOutBack, easeOutCubic, pop, FPS } from "../lib/math";
import { FONT } from "../lib/fonts";

// 2D layers that sit above the 3D picture. `sec` is seconds on the whole timeline.
export const BlackCard: React.FC<{ sec: number; s0: number; s1: number; text: string; loud: number; portrait?: boolean }> = ({ sec, s0, s1, text, loud, portrait = false }) => {
  if (sec < s0 || sec >= s1) return null;
  const p = (sec - s0) / (s1 - s0);
  const reveal = clamp(p / 0.78);                                  // writes on in sync with the line
  const sc = pop(sec - s0, 0.25) * (1 + 0.02 * loud);
  return (
    <AbsoluteFill style={{ background: "#000000", alignItems: portrait ? "center" : "flex-start", justifyContent: "center", paddingLeft: portrait ? "7%" : "13%", paddingRight: portrait ? "7%" : "4%" }}>
      <div style={{ fontFamily: FONT, fontWeight: 700, fontSize: portrait ? 92 : 190, maxWidth: portrait ? "100%" : "none", textAlign: portrait ? "center" : "left", color: "#FFFFFF", lineHeight: 1.15, transform: `scale(${sc})`, transformOrigin: portrait ? "center center" : "left center", clipPath: `inset(-20% ${(1 - reveal) * 100}% -20% 0)`, whiteSpace: portrait ? "normal" : "nowrap" }}>{text}</div>
    </AbsoluteFill>
  );
};

export const TitleCard: React.FC<{ sec: number; s0: number; s1: number; loud: number; portrait?: boolean }> = ({ sec, s0, s1, loud, portrait = false }) => {
  if (sec < s0 || sec >= s1) return null;
  const ts = sec - s0; const sc = pop(ts, 0.3) * (1 + 0.03 * loud);
  const swipe = easeOutCubic(clamp((ts - 0.35) / 0.35));
  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", background: "radial-gradient(ellipse at center, rgba(244,241,234,0.15) 0%, rgba(17,17,17,0.38) 100%)" }}>
      <AbsoluteFill style={{ background: "repeating-conic-gradient(from 0deg at 50% 50%, rgba(255,255,255,0.0) 0deg 5deg, rgba(255,255,255,0.10) 5deg 6deg)", opacity: 0.6 }} />
      <div style={{ transform: `rotate(-3deg) scale(${sc})`, textAlign: "center" }}>
        <div style={{ fontFamily: FONT, fontWeight: 700, fontSize: portrait ? 142 : 250, maxWidth: portrait ? "90vw" : "none", lineHeight: 1.1, color: "#111111", textShadow: "0 0 0 #F4F1EA, 6px 6px 0 #F4F1EA, -6px 6px 0 #F4F1EA, 6px -6px 0 #F4F1EA, -6px -6px 0 #F4F1EA, 0 9px 0 #F4F1EA" }}>थाई मांगुर</div>
        <div style={{ height: 14, margin: "0 auto", width: `${swipe * 100}%`, background: "#FF8800", border: "3px solid #111111", borderRadius: 8, transformOrigin: "left center" }} />
        <div style={{ fontFamily: FONT, fontWeight: 700, fontSize: portrait ? 27 : 46, maxWidth: portrait ? "86vw" : "none", color: "#F4F1EA", marginTop: 22, textShadow: "3px 3px 0 #111111", opacity: clamp((ts - 0.5) / 0.3) }}>The Banned Fish India Still Can't Stop Selling</div>
      </div>
    </AbsoluteFill>
  );
};

// yellow tag on a string, hanging from the top right corner; drops with a bounce, then swings and settles
export const StampTag: React.FC<{ sec: number; s0: number; s1: number; text: string; portrait?: boolean }> = ({ sec, s0, s1, text, portrait = false }) => {
  if (sec < s0 || sec >= s1) return null;
  const ts = sec - s0; const drop = easeOutBack(clamp(ts / 0.45));
  const ang = ts < 0.3 ? 0 : 14 * Math.exp(-1.6 * (ts - 0.3)) * Math.cos(7 * (ts - 0.3));
  return (
    <div style={{ position: "absolute", right: portrait ? 28 : 130, top: 0, transform: `translateY(${(drop - 1) * 260}px)`, display: "flex", flexDirection: "column", alignItems: "center" }}>
      <div style={{ width: portrait ? 3 : 4, height: portrait ? 48 : 90, background: "#111111" }} />
      <div style={{ transform: `rotate(${ang}deg)`, transformOrigin: "50% 0%", marginTop: -2 }}>
        <div style={{ background: "#E3B93C", border: portrait ? "3px solid #111111" : "5px solid #111111", borderRadius: 16, padding: portrait ? "16px 14px 12px" : "30px 30px 18px", fontFamily: FONT, fontWeight: 700, fontSize: portrait ? 22 : 40, color: "#111111", boxShadow: "6px 6px 0 rgba(0,0,0,0.25)", position: "relative", whiteSpace: "nowrap", maxWidth: portrait ? 420 : "none" }}>
          <div style={{ position: "absolute", top: 8, left: "50%", marginLeft: -9, width: 18, height: 18, borderRadius: 9, background: "#F4F1EA", border: "4px solid #111111" }} />
          {text}
        </div>
      </div>
    </div>
  );
};

// 6 to 9 frame colour wash that hides the join of a dolly-through
export const Wash: React.FC<{ frame: number; at: number; color: string }> = ({ frame, at, color }) => {
  const f0 = Math.round(at * FPS), L = 8;
  const o = frame < f0 - L || frame > f0 + L ? 0 : frame <= f0 ? (frame - (f0 - L)) / L : 1 - (frame - f0) / L;
  if (o <= 0) return null;
  return <AbsoluteFill style={{ background: color, opacity: clamp(o) }} />;
};
