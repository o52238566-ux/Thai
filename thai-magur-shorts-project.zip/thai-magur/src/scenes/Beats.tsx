import React from "react";
import * as THREE from "three";
import { V3, clamp, smooth, easeOutBack, easeOutCubic, rng, pop, lerp } from "../lib/math";
import { Shot, Beat, C14 } from "../data/beats";
import { CASTS } from "../data/cast";
import { PAL } from "../lib/draw";
import { Ink, Flat, Sign, FishView, CharacterView, Glow, Mist, Bubbles, Dust } from "../rig/kit";
import { PondWorld, WatersWorld, UnderWorld, MarketWorld, StudioWorld, StationWorld } from "../sets/worlds";

export interface BP { beat: Beat; shot: Shot; t: number; frame: number; loud: number }   // t = seconds since the beat started
const ACC = PAL.accent;
const Coin = ({ p }: { p: V3 }) => <Ink g="cyl" a={[0.13, 0.13, 0.04, 16]} color={ACC} p={p} line={0.012} />;
const CounterBoard = ({ pos, text, w = 2.4 }: { pos: V3; text: string; w?: number }) => <Sign pos={pos} size={[w, w * 0.36]} lines={[text]} bg="#111111" fg={ACC} border="#333333" />;

// ---------------- B1: cold open at dawn ----------------
function B1({ t, frame, loud }: BP) {
  const wy = -0.85 * smooth((t - 6.2) / 2.4);
  const x = -3 + 3 * clamp(t / 3.8);
  const rise = smooth((t - 4.0) / 0.6);
  const y = wy < -0.01 ? Math.max(wy - 0.05, -0.42) : -0.62 + 0.57 * rise;
  return (<>
    <PondWorld t={t} tod="dawn" waterY={wy} />
    <Mist y={0.25} t={t} seed={1} count={6} opacity={0.3} z0={-3} zr={7} fade={1 - smooth((t - 6) / 2)} />
    <FishView kind="hero" pos={[x, y, -2.2]} len={2.4} glow loud={loud} frame={frame} />
  </>);
}
// ---------------- B2 / B12: market ----------------
function Market({ beat, t, frame, loud }: BP) {
  const b12 = beat.id === "B12";
  return (<>
    <MarketWorld t={t} mode={b12 ? "nets" : "cross"} />
    <FishView kind="hero" pos={[-0.4, 1.2, -1.2]} len={0.95} glow loud={loud} frame={frame} />
    {b12 && <Sign pos={[-0.4, 0.74, -0.52]} size={[0.62, 0.22]} lines={["BANNED"]} fs={46} />}
    {b12 && CASTS.B12.map(c => <CharacterView key={c.id} cast={c} t={t} frame={frame} />)}
  </>);
}
// ---------------- B3: African catfish brought across (table map) ----------------
function B3({ t, shot, frame, loud }: BP) {
  const a = shot.id === "3a";
  const tagT = t - 0.9;
  const tagY = 2.7 - 1.0 * easeOutBack(clamp(tagT / 0.45));
  const swing = tagT > 0 ? 0.3 * Math.exp(-2.2 * tagT) * Math.cos(8 * tagT) : 0;
  const cx = -1.1 + 2.2 * smooth((t - 2.6) / 2.2);
  const drop = clamp((t - 3.3) / 0.25);
  const stampY = lerp(2.6, 0.34, drop * drop);
  return (<>
    <StudioWorld t={t} />
    {a && <>
      <Ink g="box" a={[2.8, 0.9, 1.0]} color={PAL.wood} p={[0, 0.45, 0]} />
      <FishView kind="hero" pos={[0, 1.4, 0]} len={2.2} glow loud={loud} frame={frame} />
      <group position={[0.9, tagY + 0.55, 0.3]} rotation={[0, 0, swing]}>
        <Ink g="cyl" a={[0.012, 0.012, 0.55, 6]} color="#333" p={[0, -0.27, 0]} noLine />
        <Sign pos={[0, -0.8, 0]} size={[1.5, 0.4]} lines={["AFRICAN CATFISH"]} fs={50} billboard={false} />
      </group>
    </>}
    {!a && <>
      <Ink g="box" a={[2.4, 0.3, 2.4]} color={PAL.wood} p={[-2.6, 0.15, 0]} /><Ink g="box" a={[2.4, 0.3, 2.4]} color={PAL.teal} p={[2.6, 0.15, 0]} />
      <Sign pos={[-2.6, 0.32, 0]} size={[1.8, 0.6]} lines={["AFRICA"]} billboard={false} rot={[-Math.PI / 2, 0, 0]} fs={110} />
      <Sign pos={[2.6, 0.32, 0]} size={[1.8, 0.6]} lines={["INDIA"]} billboard={false} rot={[-Math.PI / 2, 0, 0]} fs={110} />
      {Array.from({ length: 6 }, (_, i) => <Ink key={i} g="box" a={[0.22, 0.04, 0.08]} color={PAL.ink} p={[-1.0 + i * 0.4, 0.04, 0]} noLine />)}
      <Ink g="box" a={[0.5, 0.4, 0.5]} color="#B9A25A" p={[cx, 0.42 + 0.06 * Math.abs(Math.sin(t * 7)), 0]} />
      <Sign pos={[0.9, stampY, 0.55]} size={[1.5, 0.62]} lines={["अवैध"]} billboard={false} rot={[-Math.PI / 2, 0, -0.2]} fs={90} scale={drop >= 1 ? pop(t - 3.55) : 1} />
    </>}
  </>);
}
// ---------------- B4: the farmer wants a fast, cheap fish ----------------
function B4({ t, frame }: BP) {
  const g = easeOutBack(clamp((t - 2.8) / 0.3));
  const tag = clamp((t - 4.4) / 0.3); const tagY = lerp(3.2, 1.4, easeOutCubic(tag));
  return (<>
    <PondWorld t={t} tod="day" />
    {CASTS.B4.map(c => <CharacterView key={c.id} cast={c} t={t} frame={frame} />)}
    <Ink g="box" a={[0.3, 2.2, 0.08]} color={PAL.wood} p={[-2, 1.1, 3]} />
    {Array.from({ length: 6 }, (_, i) => <Ink key={i} g="box" a={[0.2, 0.04, 0.1]} color={PAL.paper} p={[-1.8, 0.4 + i * 0.35, 3.06]} noLine />)}
    <FishView kind="native" pos={[-2.0, 0.5 + 0.4 * g, 3.12]} len={0.3 + 0.55 * g} frame={frame} />
    <Sign pos={[-0.9, tagY, 3.0]} size={[0.9, 0.45]} lines={["₹ कम"]} bg={PAL.paper} fg={ACC} />
  </>);
}
// ---------------- B5: six months, 400 g to 1 kg ----------------
function B5({ t, shot, frame, loud }: BP) {
  const pages = Array.from({ length: 6 }, (_, i) => { const ti = 0.15 + 0.28 * i, tt = t - ti; return { i, tt }; });
  const grams = Math.round(400 + 600 * smooth((t - 2.0) / 1.4));
  return (<>
    <StudioWorld t={t} />
    <Ink g="box" a={[1.4, 1.8, 0.08]} color={PAL.paper} p={[-1.2, 1.9, -1.5]} />
    <Ink g="box" a={[1.4, 0.3, 0.1]} color={PAL.slate} p={[-1.2, 2.65, -1.47]} line={0.02} />
    <Sign pos={[-1.2, 1.85, -1.45]} size={[1.1, 0.5]} lines={["6 महीने"]} billboard={false} />
    {pages.map(({ i, tt }) => {
      const y = tt < 0 ? 1.9 : 1.9 - 4.9 * tt * tt - 0.4 * tt; if (y < -0.4) return null;
      return <Sign key={i} pos={[-1.2 + (tt > 0 ? 0.35 * tt : 0), y, -1.4 + i * 0.004 + (tt > 0 ? 0.2 : 0)]} size={[1.25, 1.55]} lines={[String(i + 1)]} billboard={false} rot={[0, 0, tt > 0 ? 2.4 * tt : 0]} fs={190} />;
    })}
    <group position={[1.8, 0, -0.5]}><Ink g="box" a={[1.4, 0.25, 0.9]} color={PAL.slate} p={[0, 0.12, 0]} /><Ink g="cyl" a={[0.1, 0.12, 0.9, 12]} color="#7C8F94" p={[0, 0.7, 0]} /><Ink g="cyl" a={[0.6, 0.6, 0.07, 24]} color="#B8C2C6" p={[0, 1.18, 0]} /></group>
    <FishView kind="hero" pos={[1.8, 1.55, -0.5]} len={1.0} glow loud={loud} frame={frame} />
    <CounterBoard pos={[1.8, 2.35, -0.5]} text={`${grams} g`} w={1.7} />
  </>);
}
// ---------------- B6: money making machine ----------------
function B6({ t, frame, loud }: BP) {
  const n = Math.floor(46 * clamp((t - 0.9) / 1.1));
  const fy = 3.2 - 1.6 * smooth((t - 0.2) / 0.6);
  return (<>
    <PondWorld t={t} tod="day" />
    <Ink g="box" a={[1.4, 1.4, 1.0]} color={PAL.slate} p={[-2.5, 0.7, 3.0]} />
    <Ink g="cone" a={[0.7, 0.7, 4]} color={PAL.teal} p={[-2.5, 1.75, 3.0]} r={[Math.PI, Math.PI / 4, 0]} />
    <Ink g="cyl" a={[0.3, 0.3, 0.12, 16]} color="#B8C2C6" p={[-1.77, 1.0, 3.0]} r={[0, 0, Math.PI / 2]} />
    <Ink g="box" a={[0.6, 0.12, 0.6]} color="#7C8F94" p={[-1.6, 0.5, 3.35]} r={[0.2, 0, -0.2]} />
    <Sign pos={[-2.5, 0.9, 3.52]} size={[0.9, 0.5]} lines={["₹"]} bg="#111111" fg={ACC} />
    {t > 0.2 && t < 0.85 && <FishView kind="hero" pos={[-2.5, fy, 3.0]} len={0.7} glow loud={loud} frame={frame} />}
    {Array.from({ length: n }, (_, i) => { const layer = Math.floor(i / 10), k = i % 10, a = k * 0.63 + layer, rr = 0.34 - layer * 0.05; return <Coin key={i} p={[-1.15 + Math.cos(a) * rr, 0.03 + layer * 0.045, 3.6 + Math.sin(a) * rr * 0.8]} />; })}
    {n > 4 && <Glow pos={[-1.15, 0.25, 3.6]} size={2.2} opacity={0.3} loud={loud * 0.5} />}
    {CASTS.B6.map(c => <CharacterView key={c.id} cast={c} t={t} frame={frame} />)}
  </>);
}
// ---------------- B7: breathing air ----------------
function B7({ t, frame, loud }: BP) {
  const m = Math.pow(Math.max(0, Math.sin(t * 2.6)), 2);
  const sg = pop(t - 2.3, 0.3);
  return (<>
    <PondWorld t={t} tod="day" />
    {[0, 1, 2].map(k => { const u = (t * 0.8 + k / 3) % 1; return <mesh key={k} position={[1.1, 0.012, 0.25]} rotation={[-Math.PI / 2, 0, 0]} scale={[0.3 + u * 1.2, (0.3 + u * 1.2) * 0.6, 1]}><ringGeometry args={[0.9, 1, 32]} /><meshBasicMaterial color={PAL.ink} transparent opacity={0.7 * (1 - u)} depthWrite={false} /></mesh>; })}
    <FishView kind="hero" pos={[0.1, -0.12, 0.2]} len={2.4} mouth={m} glow loud={loud} frame={frame} />
    <Bubbles c={[1.15, 0, 0.3]} spread={[0.5, 0.3]} count={7} t={t} seed={4} y0={0.1} />
    <group position={[-2.4, 0, 1.4]} scale={sg}><Ink g="cyl" a={[0.05, 0.05, 1.5, 8]} color={PAL.wood} p={[0, 0.75, 0]} /><Sign pos={[0, 1.55, 0.05]} size={[1.5, 0.55]} lines={["हवा में साँस"]} /></group>
  </>);
}
// ---------------- B8: dirty pond, normal fish die, magur lives ----------------
function B8({ t, frame, loud }: BP) {
  const xs = [-3.4, -1.9, -0.4, 1.1, 2.6], flips = [-1, -1, 0.7, 1.5, 2.3];
  const heroShow = t >= 3.43; const hx = t >= 6.13 ? 4.4 : 0.5;
  return (<>
    <PondWorld t={t} tod="day" murky foreReeds />
    <Bubbles c={[0, 0, -1.2]} spread={[9, 3]} count={14} t={t} seed={3} />
    {xs.map((x, i) => { const d = t > flips[i]; return <FishView key={i} kind="native" pos={[x, d ? -0.02 + 0.01 * Math.sin(t * 2 + i) : -0.25, -1.2]} len={0.8} flipY={d} dead={d} wiggle={d ? 0 : 0.06} frame={frame} />; })}
    {heroShow && <FishView kind="hero" pos={[hx, -0.05, -0.2]} len={2.4} mouth={Math.pow(Math.max(0, Math.sin(t * 2.4)), 2)} glow loud={loud} frame={frame} />}
    {heroShow && t < 6.13 && <><Glow pos={[hx + 0.62, 0.0, -0.15]} size={0.7} loud={loud} opacity={0.8} /><Sign pos={[hx + 1.1, 0.95, -0.1]} size={[1.1, 0.4]} lines={["ख़ास अंग"]} fs={52} /></>}
  </>);
}
// ---------------- B9: pond -> river ----------------
function B9({ t, frame, loud }: BP) {
  const x0 = -14 + 7.64 * Math.max(0, t - 0.9);
  const fish = Array.from({ length: 6 }, (_, j) => ({ j, x: x0 - 1.4 * j, z: ((j % 3) - 1) * 0.55 })).filter(f => f.x > -12.2 && f.x < 46);
  return (<>
    <WatersWorld t={t} />
    {fish.map(f => <FishView key={f.j} kind="hero" pos={[f.x, 0.14, f.z]} len={1.3} glow loud={loud} frame={frame + f.j * 3} />)}
  </>);
}
// ---------------- B10: predator, native fish flee ----------------
function B10({ t, frame, loud }: BP) {
  const hx = t > 2.5 ? -1.2 + 2.6 * (t - 2.5) : -1.2;
  const base: V3[] = [[2.6, 1.2, -0.3], [3.4, 2.0, 0.4], [4.2, 1.0, -0.6], [2.9, 2.4, 0.8], [4.8, 1.8, 0.2], [3.8, 0.8, 0.6], [2.2, 1.9, -0.8], [5.2, 1.2, -0.2]];
  const flare = smooth((t - 0.3) / 0.3) * 0.12;
  return (<>
    <UnderWorld t={t} />
    {t > 2.5 && <mesh position={[hx - 0.8, 1.8, -0.4]}><planeGeometry args={[3.4, 6]} /><meshBasicMaterial color="#0B2A33" transparent opacity={0.26} depthWrite={false} /></mesh>}
    <FishView kind="hero" pos={[hx, 2.4 - (t > 2.5 ? 0.3 : 0), 0]} len={3.2 + flare * 4} glow loud={loud} frame={frame} />
    {base.map((b, i) => {
      const f = i === 3 ? 0 : smooth((hx + 1.2 - b[0] + 0.2) / 1.0);
      const p: V3 = [b[0] + 1.8 * f * (0.6 + 0.4 * Math.cos(i)), b[1] + 1.2 * f * Math.sin(i * 1.7), b[2] + 0.8 * f * Math.cos(i * 2.1)];
      return <FishView key={i} kind="native" pos={p} len={0.8} wiggle={0.07 + 0.1 * f} frame={frame + i * 5} />;
    })}
  </>);
}
// ---------------- B13: Jabalpur then Assam ----------------
function B13({ t, shot, frame, loud }: BP) {
  if (t < 4.63) {
    const v = Math.round(8000 * smooth((t - 2.2) / 1.4));
    const cols = [PAL.slate, PAL.teal, PAL.wood];
    return (<>
      <StationWorld t={t} />
      <Dust c={[1, 0.3, -2]} size={[2.4, 4, 2.4]} count={22} t={t} seed={5} />
      {[-2.0, 0, 2.0].map((x, i) => <group key={i}><Ink g="box" a={[1.8, 1.2, 1.4]} color={cols[i]} p={[x, 0.6, -1.8]} /><Ink g="box" a={[1.9, 0.12, 1.5]} color="#B8C2C6" p={[x, 1.26, -1.8]} line={0.02} /></group>)}
      <CounterBoard pos={[0, 3.2, -1.8]} text={v.toLocaleString("en-US")} w={3.0} />
      {CASTS.B13s.map(c => <CharacterView key={c.id} cast={c} t={t} frame={frame} />)}
    </>);
  }
  const tp = t - 6.13; const q = 7 * smooth((tp - 0.3) / 1.4);
  const r = rng(3);
  return (<>
    <PondWorld t={t} tod="day" />
    {Array.from({ length: 9 }, (_, i) => <Ink key={i} g="box" a={[0.7, 0.4, 0.5]} color={i % 2 ? "#B9A25A" : "#9A844A"} p={[1.6 + (i % 3) * 0.75, 0.2 + Math.floor(i / 6) * 0.4, 0.2 + Math.floor((i % 6) / 3) * 0.55]} r={[0, (r() - 0.5) * 0.3, 0]} line={0.025} />)}
    <Flat w={1.6} d={1.2} color="#2A1D12" p={[4.2, 0.02, 0.6]} /><Ink g="box" a={[1.8, 0.1, 0.12]} color="#6B4A2C" p={[4.2, 0.05, 1.25]} line={0.02} />
    <Ink g="cyl" a={[0.07, 0.07, 2.4, 8]} color={PAL.wood} p={[2.6, 1.2, -1.0]} line={0.02} />
    <CounterBoard pos={[2.6, 2.55, -1.0]} text={`${q.toFixed(q >= 6.95 ? 0 : 1)} क्विंटल`} w={2.0} />
    {CASTS.B13p.map(c => <CharacterView key={c.id} cast={c} t={t} frame={frame} />)}
  </>);
}
// ---------------- B14: close on the opening image ----------------
function B14({ t, shot, frame, loud }: BP) {
  const th = 0.34 * easeOutBack(clamp((t - 2.6) / 0.45));
  const pivot: V3 = [0, 1.65, 3.2];
  const t14b = t - 3.17; const shx = -3.5 + 1.1 * Math.max(0, t14b);
  const orbitT = t - 5.27;                           // 14c starts at 80.6 s
  const fadeAt = (i: number) => 1 - smooth((t - (6.27 + i * 0.6)) / 0.5);
  const nat: V3[] = [[-1.9, 0.12, -0.2], [1.8, 0.1, -1.9], [-1.2, 0.1, -2.4], [2.4, 0.14, 0.4], [0.9, 0.1, 1.0]];
  return (<>
    <PondWorld t={t} tod="dusk" />
    <Mist y={0.22} t={t} seed={8} count={7} opacity={0.22} color="#D6D6DE" z0={-2} zr={7} fade={smooth((t - 3.2) / 1.0)} />
    <group position={[0, 0, 3.2]}>
      <Ink g="sphere" a={[0.9]} color="#8E8A78" p={[0, 0.3, 0]} s={[1.3, 0.6, 1]} />
      <Ink g="cyl" a={[0.07, 0.09, 1.4, 10]} color={PAL.wood} p={[0, 0.9, 0]} />
    </group>
    <group position={pivot}>
      <group rotation={[0, 0, th]}>
        <Ink g="box" a={[2.2, 0.08, 0.1]} color={PAL.wood} line={0.02} />
        {[0, 1].map((k) => <group key={k} position={[k ? 1.0 : -1.0, 0, 0]} rotation={[0, 0, -th]}>
          <Ink g="cyl" a={[0.01, 0.01, 0.55, 6]} color="#333" p={[0, -0.28, 0]} noLine />
          <Ink g="cyl" a={[0.42, 0.34, 0.06, 20]} color="#B9A25A" p={[0, -0.58, 0]} line={0.02} />
          {k === 0 && Array.from({ length: 14 }, (_, i) => <Coin key={i} p={[Math.cos(i * 1.2) * (0.12 + 0.15 * (i % 3)), -0.52 + 0.04 * Math.floor(i / 5), Math.sin(i * 1.2) * 0.1]} />)}
        </group>)}
      </group>
    </group>
    {[0, 1, 2].map(i => <FishView key={"p" + i} kind="native" pos={[pivot[0] + 1.0 + (i - 1) * 0.12, pivot[1] + Math.sin(th) * 1.0 - 0.45 + i * 0.05, pivot[2] + 0.05]} len={0.35} frame={frame} wiggle={0} />)}
    {shx > -3.4 && <mesh position={[shx, -0.015, -2.2]} rotation={[-Math.PI / 2, 0, 0]} scale={[1.6, 0.5, 1]}><circleGeometry args={[1, 24]} /><meshBasicMaterial color="#10222A" transparent opacity={0.4} depthWrite={false} /></mesh>}
    {t >= 5.27 && <>
      <FishView kind="hero" pos={[C14[0], 0.15, C14[2]]} len={2.2} glow loud={loud} frame={frame} />
      {nat.map((p, i) => fadeAt(i) > 0.01 && <FishView key={i} kind="native" pos={p} len={0.7} opacity={fadeAt(i)} frame={frame + i * 4} />)}
    </>}
  </>);
}

export function BeatWorld(p: BP) {
  switch (p.beat.id) {
    case "B1": return <B1 {...p} />;
    case "B2": case "B12": return <Market {...p} />;
    case "B3": return <B3 {...p} />;
    case "B4": return <B4 {...p} />;
    case "B5": return <B5 {...p} />;
    case "B6": return <B6 {...p} />;
    case "B7": return <B7 {...p} />;
    case "B8": return <B8 {...p} />;
    case "B9": return <B9 {...p} />;
    case "B10": return <B10 {...p} />;
    case "B13": return <B13 {...p} />;
    case "B14": return <B14 {...p} />;
    default: return null;
  }
}
