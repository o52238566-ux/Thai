# थाई मांगुर: documentary project (Remotion + Three.js)

Landscape: 1920x1080; YouTube Shorts: 1080x1920; both 30 fps, 2,546 frames (84.85 s). The voice-over is `public/voice.mp3`; timings and loudness are in `src/data`.
Everything on screen is drawn in code: no image files, no stock assets. The project now includes a separate portrait composition (`ThaiMagurShorts`) with portrait-sized title cards and a wider camera field of view; the original landscape composition remains available.

## Run it
```bash
npm install
npm run check            # staging check (framing, camera distance, clearances)
npm run check:timeline   # beats and shots cover the audio with no gaps
npm run fonts            # optional, needs network: embeds Kalam (handwritten Hindi) instead of FreeSans Bold
npm run studio           # preview in the browser
npm run still            # one test frame -> out/still.png (do this before a full render)
npm run render           # landscape -> out/thai-magur.mp4
npm run render:shorts    # vertical 9:16 Shorts -> out/thai-magur-shorts.mp4
```
`render` uses `--gl=angle`, which is what the Remotion docs recommend for Three.js on a machine with a graphics card.
Please confirm the flag in the current Remotion docs, since options change between versions. If frames come out black, try `--gl=swangle`.
`render:cpu` renders only the first 10 s with no sound, as a slow-machine test.

## What was checked, and what was not
Checked here (by running code):
- `check` passes: no character is cut by the frame edge, no camera is closer than 3.4 m to a character, spacing and prop clearances hold.
- `check:timeline` passes: 14 beats, 31 shots, every frame resolves to one shot, all 14 sentences start inside their own beat, camera poses are finite on all 2,546 frames.
- Character and fish drawing code was run in a browser and compared with your sheet.
- The TypeScript was type-checked with the external packages stubbed.

**Not checked: nothing here has been rendered through Remotion or Three.js.** Those packages could not be installed in my workspace (no network), so I have not seen a single frame of the 3D scenes. Expect to fix small things on the first `still` or `studio` run. Frames worth looking at first:
- frame 60 (B1 pond), 330 (title card), 1000 (B6 coin machine), 1260 (B8 murky pond), 1500 (B9 follow shot), 1920 (B13 station), 2300 (B14 orbit)
- the B7 to B8 and B9 to B10 colour washes, and the B13 whip-pan at about 69.6 to 70.3 s.

## Known simplifications
- Shadows are soft dark discs under characters, not shadow-mapped.
- Characters and fish are flat cut-outs that turn to face the camera; the side and back views are drawn separately and swapped by angle.
- Mouth shapes are not driven by the voice because nobody speaks on screen. Loudness drives the title and card word-pops and the glow on the hero fish.
- Camera moves are Catmull-Rom splines with a slight hand-held drift. Cut times inside a sentence are estimated from word position, not from per-word timings.
- Font: FreeSans Bold is embedded as the fallback. Kalam looks better; run `npm run fonts` once.


## YouTube Shorts export

After `npm install`, run `npm run render:shorts`. This renders `ThaiMagurShorts` at 1080x1920 (9:16), 30 fps, with the same 2,546-frame timeline and voice-over. The landscape `ThaiMagur` composition and `npm run render` command are unchanged. Preview in `npm run studio` and select `ThaiMagurShorts` before a full export.
